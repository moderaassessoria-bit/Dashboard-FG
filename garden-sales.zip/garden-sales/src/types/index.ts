export type RoleMode = 'guilherme' | 'vendedores' | 'diretoria';

export type PageId = 
  | 'dashboard'
  | 'equipe'
  | 'vendedores'
  | 'loja'
  | 'lancamentos'
  | 'metas'
  | 'analises'
  | 'configuracoes';

export interface SaleEntry {
  id: string;
  data: string; // YYYY-MM-DD or DD/MM/YYYY
  vendedor: string;
  faturamento: number;
  numVendas: number;
  ticketMedio: number;
  observacao?: string;
  origem?: 'manual' | 'sheets' | 'demo';
  createdAt: string;
}

export interface Seller {
  id: string;
  nome: string;
  ativo: boolean;
  metaReferenciaPercentual?: number; // e.g. 33.33%
  cor?: string;
}

export interface SystemConfig {
  // Loja
  metaLoja: number; // e.g. 400000
  mediaHistoricaLoja: number; // e.g. 354000
  percentualRemuneracaoLoja: number; // e.g. 2.0 (%)
  
  // Equipe
  metaEquipe: number; // e.g. 155000
  mediaHistoricaEquipe: number; // e.g. 140000
  bonusPorVendedor: number; // e.g. 200

  // Pontos
  percentualIncrementoPontos: number; // e.g. 10 (%)
  pontosPorIncremento: number; // e.g. 100
  valorPorPonto: number; // e.g. 1 (R$ 1,00 por ponto -> 100 pts = R$ 100)

  // Operacional
  mesReferencia: string; // e.g. "2026-09"
  nomeMesReferencia: string; // e.g. "Setembro 2026"
  diasOperacionais: number; // e.g. 26 or 30
  diasDecorridos: number; // e.g. 24

  // Integração Google Sheets
  googleSheetsUrl?: string;
  googleSheetsConnected?: boolean;
  ultimaSincronizacao?: string;
}

export interface WeeklyBreakdown {
  semana: number;
  label: string;
  diasPeriodo: string;
  meta: number;
  realizado: number;
  gap: number;
  atingimentoPercent: number;
  status: 'atingido' | 'atencao' | 'critico';
}

export interface TeamKpis {
  meta: number;
  realizado: number;
  atingimentoPercent: number;
  falta: number;
  faltaPercent: number;
  numVendas: number;
  ticketMedio: number;
  ritmoAtual: number;
  ritmoNecessario: number;
  projecao: number;
  statusRitmo: 'positivo' | 'alerta' | 'negativo';
  pontos: number;
  valorPontos: number;
  proximoNivelMeta: number;
  faltaProximoNivel: number;
  bonusElegivel: boolean;
  bonusTotal: number;
}

export interface StoreKpis {
  meta: number;
  mediaHistorica: number;
  realizado: number;
  atingimentoPercent: number;
  falta: number;
  faltaPercent: number;
  excedenteMedia: number;
  remuneracaoGestor: number;
  remuneracaoProjetada: number;
  numVendas: number;
  ticketMedio: number;
  ritmoAtual: number;
  ritmoNecessario: number;
  projecao: number;
  statusRitmo: 'positivo' | 'alerta' | 'negativo';
  diasOperacionais: number;
  diasDecorridos: number;
  diasRestantes: number;
}

export interface SellerPerformance {
  nome: string;
  faturamento: number;
  numVendas: number;
  ticketMedio: number;
  participacaoEquipePercent: number;
  metaReferencia: number;
  atingimentoPercent: number;
  falta: number;
  mediaDiaria: number;
  status: 'positivo' | 'alerta' | 'negativo';
}

export interface SmartAlert {
  id: string;
  tipo: 'positivo' | 'alerta' | 'negativo';
  titulo: string;
  mensagem: string;
  categoria: 'equipe' | 'loja' | 'ticket' | 'ritmo';
}
