import { SaleEntry, Seller, SystemConfig } from '../types';
import { INITIAL_CONFIG, INITIAL_ENTRIES, INITIAL_SELLERS } from '../data/initialData';
import { calculateTicket } from '../utils/calculations';

const STORAGE_KEYS = {
  ENTRIES: 'garden_sales_entries_v1',
  CONFIG: 'garden_sales_config_v1',
  SELLERS: 'garden_sales_sellers_v1',
  LAST_SYNC: 'garden_sales_last_sync_v1',
};

class DataService {
  public getEntries(): SaleEntry[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ENTRIES);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Erro ao carregar lançamentos do localStorage:', e);
    }
    this.saveEntries(INITIAL_ENTRIES);
    return INITIAL_ENTRIES;
  }

  public saveEntries(entries: SaleEntry[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ENTRIES, JSON.stringify(entries));
    } catch (e) {
      console.error('Erro ao salvar lançamentos no localStorage:', e);
    }
  }

  public addEntry(entryData: Omit<SaleEntry, 'id' | 'ticketMedio' | 'createdAt'>): SaleEntry {
    const entries = this.getEntries();
    const ticketMedio = calculateTicket(entryData.faturamento, entryData.numVendas);
    const newEntry: SaleEntry = {
      ...entryData,
      id: `entry-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      ticketMedio,
      createdAt: new Date().toISOString(),
    };

    const updated = [newEntry, ...entries];
    this.saveEntries(updated);
    this.touchLastSync();
    return newEntry;
  }

  public updateEntry(id: string, partial: Partial<Omit<SaleEntry, 'id' | 'createdAt'>>): SaleEntry | null {
    const entries = this.getEntries();
    const index = entries.findIndex((e) => e.id === id);
    if (index === -1) return null;

    const existing = entries[index];
    const faturamento = partial.faturamento !== undefined ? partial.faturamento : existing.faturamento;
    const numVendas = partial.numVendas !== undefined ? partial.numVendas : existing.numVendas;
    const ticketMedio = calculateTicket(faturamento, numVendas);

    const updatedEntry: SaleEntry = {
      ...existing,
      ...partial,
      ticketMedio,
    };

    entries[index] = updatedEntry;
    this.saveEntries(entries);
    this.touchLastSync();
    return updatedEntry;
  }

  public deleteEntry(id: string): boolean {
    const entries = this.getEntries();
    const filtered = entries.filter((e) => e.id !== id);
    if (filtered.length !== entries.length) {
      this.saveEntries(filtered);
      this.touchLastSync();
      return true;
    }
    return false;
  }

  public getConfig(): SystemConfig {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CONFIG);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Erro ao carregar configurações:', e);
    }
    this.saveConfig(INITIAL_CONFIG);
    return INITIAL_CONFIG;
  }

  public saveConfig(config: SystemConfig): void {
    try {
      localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(config));
    } catch (e) {
      console.error('Erro ao salvar configurações:', e);
    }
  }

  public getSellers(): Seller[] {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.SELLERS);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.warn('Erro ao carregar vendedores:', e);
    }
    this.saveSellers(INITIAL_SELLERS);
    return INITIAL_SELLERS;
  }

  public saveSellers(sellers: Seller[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.SELLERS, JSON.stringify(sellers));
    } catch (e) {
      console.error('Erro ao salvar vendedores:', e);
    }
  }

  public resetToDemo(): void {
    this.saveEntries(INITIAL_ENTRIES);
    this.saveConfig(INITIAL_CONFIG);
    this.saveSellers(INITIAL_SELLERS);
    this.touchLastSync();
  }

  public clearAllEntries(): void {
    this.saveEntries([]);
    this.touchLastSync();
  }

  public getLastSyncTime(): string {
    const now = new Date();
    const day = String(now.getDate()).padStart(2, '0');
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const year = now.getFullYear();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    return `${day}/${month}/${year} ${hours}:${minutes}`;
  }

  public touchLastSync(): string {
    const str = this.getLastSyncTime();
    try {
      localStorage.setItem(STORAGE_KEYS.LAST_SYNC, str);
    } catch (_) {}
    return str;
  }

  /**
   * Exporta a tabela DADOS_VENDAS no formato Google Sheets especificado na Seção 36.
   * DATA, VENDEDOR, FATURAMENTO, NUM_VENDAS, TICKET_MEDIO
   */
  public exportSalesCsv(): string {
    const entries = this.getEntries();
    const headers = ['DATA', 'VENDEDOR', 'FATURAMENTO', 'NUM_VENDAS', 'TICKET_MEDIO'];
    const rows = entries.map((e) => [
      e.data,
      `"${e.vendedor.replace(/"/g, '""')}"`,
      e.faturamento.toFixed(2),
      e.numVendas,
      e.ticketMedio.toFixed(2),
    ]);

    return [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }

  /**
   * Exporta a aba CONFIG no formato Google Sheets especificado na Seção 36.
   * META_LOJA, MEDIA_LOJA, META_EQUIPE, MEDIA_EQUIPE, BONUS_META, PERCENTUAL_PONTOS, VALOR_PONTOS, DIAS_OPERACIONAIS, PERCENTUAL_REMUNERACAO_LOJA
   */
  public exportConfigCsv(): string {
    const config = this.getConfig();
    const headers = [
      'META_LOJA',
      'MEDIA_LOJA',
      'META_EQUIPE',
      'MEDIA_EQUIPE',
      'BONUS_META',
      'PERCENTUAL_PONTOS',
      'VALOR_PONTOS',
      'DIAS_OPERACIONAIS',
      'PERCENTUAL_REMUNERACAO_LOJA',
    ];
    const row = [
      config.metaLoja,
      config.mediaHistoricaLoja,
      config.metaEquipe,
      config.mediaHistoricaEquipe,
      config.bonusPorVendedor,
      config.percentualIncrementoPontos,
      config.valorPorPonto,
      config.diasOperacionais,
      config.percentualRemuneracaoLoja,
    ];

    return [headers.join(','), row.join(',')].join('\n');
  }

  /**
   * Importa lançamentos a partir de CSV ou texto tabulado (Google Sheets copy/paste)
   */
  public importSalesFromCsv(csvText: string): { success: boolean; count: number; error?: string } {
    try {
      const lines = csvText.trim().split(/\r?\n/);
      if (lines.length < 2) {
        return { success: false, count: 0, error: 'Arquivo vazio ou sem linhas de dados.' };
      }

      // Check delimiter (, or ; or \t)
      const firstLine = lines[0];
      let delimiter = ',';
      if (firstLine.includes('\t')) delimiter = '\t';
      else if (firstLine.includes(';') && !firstLine.includes(',')) delimiter = ';';

      const parsedEntries: SaleEntry[] = [];
      // Skip header if line contains 'DATA' or 'VENDEDOR'
      const startIdx = firstLine.toUpperCase().includes('VENDEDOR') ? 1 : 0;

      for (let i = startIdx; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;
        const cols = line.split(delimiter).map((c) => c.replace(/^["']|["']$/g, '').trim());
        if (cols.length >= 3) {
          const data = cols[0];
          const vendedor = cols[1];
          const faturamento = parseFloat(cols[2].replace(/[^\d.,-]/g, '').replace(',', '.')) || 0;
          const numVendas = parseInt(cols[3] || '1', 10) || 1;
          const ticketMedio = calculateTicket(faturamento, numVendas);

          parsedEntries.push({
            id: `import-${Date.now()}-${i}`,
            data,
            vendedor,
            faturamento,
            numVendas,
            ticketMedio,
            createdAt: new Date().toISOString(),
            origem: 'sheets',
          });
        }
      }

      if (parsedEntries.length === 0) {
        return { success: false, count: 0, error: 'Nenhum lançamento válido encontrado no CSV.' };
      }

      const existing = this.getEntries();
      this.saveEntries([...parsedEntries, ...existing]);
      this.touchLastSync();
      return { success: true, count: parsedEntries.length };
    } catch (e: any) {
      return { success: false, count: 0, error: e.message || 'Falha ao processar CSV.' };
    }
  }

  /**
   * Sincronização em tempo real com Google Sheets (busca via Fetch se URL informada ou simula)
   */
  public async syncGoogleSheets(url?: string): Promise<{ success: boolean; message: string; count?: number }> {
    const config = this.getConfig();
    const targetUrl = url || config.googleSheetsUrl;

    if (!targetUrl) {
      // Simulação instantânea de sincronização com Google Sheets
      await new Promise((resolve) => setTimeout(resolve, 600));
      const syncTime = this.touchLastSync();
      return {
        success: true,
        message: `Dados sincronizados com sucesso localmente. Última atualização: ${syncTime}`,
      };
    }

    try {
      const response = await fetch(targetUrl);
      if (!response.ok) {
        throw new Error(`Falha HTTP ${response.status}: ${response.statusText}`);
      }
      const text = await response.text();
      const importResult = this.importSalesFromCsv(text);
      if (importResult.success) {
        return {
          success: true,
          count: importResult.count,
          message: `Sincronizado com Google Sheets! ${importResult.count} lançamentos atualizados.`,
        };
      } else {
        throw new Error(importResult.error || 'Formato de planilha inválido');
      }
    } catch (e: any) {
      return {
        success: false,
        message: `Não foi possível sincronizar com a URL da planilha: ${e.message}`,
      };
    }
  }
}

export const dataService = new DataService();
