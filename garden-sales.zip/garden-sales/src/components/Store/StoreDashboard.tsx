import React, { useState } from 'react';
import { StoreKpis, SystemConfig, SaleEntry } from '../../types';
import { formatCurrency, formatPercent, formatNumber } from '../../utils/formatters';
import { TargetGauge } from '../Dashboard/TargetGauge';
import { ProgressBar } from '../Common/ProgressBar';
import { Badge } from '../Common/Badge';
import { clsx } from 'clsx';
import {
  Store,
  DollarSign,
  TrendingUp,
  Award,
  Sparkles,
  Calculator,
  Calendar,
  Layers,
  ArrowUpRight,
} from 'lucide-react';

interface StoreDashboardProps {
  storeKpis: StoreKpis;
  config: SystemConfig;
  entries: SaleEntry[];
  onOpenNewEntry: () => void;
}

export const StoreDashboard: React.FC<StoreDashboardProps> = ({
  storeKpis,
  config,
  entries,
  onOpenNewEntry,
}) => {
  const [simulationRevenue, setSimulationRevenue] = useState<number>(400000);

  // Calcula simulação
  const mediaHistorica = config.mediaHistoricaLoja || 354000;
  const percRemuneracao = (config.percentualRemuneracaoLoja || 2) / 100;
  const simuladoExcedente = Math.max(0, simulationRevenue - mediaHistorica);
  const simuladoRemuneracao = simuladoExcedente * percRemuneracao;

  // Split por vendedor/canal
  const teamTotal = entries
    .filter((e) => ['alessandra', 'felipe', 'arnaldo'].includes(e.vendedor.toLowerCase()))
    .reduce((acc, curr) => acc + curr.faturamento, 0);

  const balcaoTotal = entries
    .filter((e) => !['alessandra', 'felipe', 'arnaldo'].includes(e.vendedor.toLowerCase()))
    .reduce((acc, curr) => acc + curr.faturamento, 0);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Top Banner: Contexto do Negócio */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Store className="w-4 h-4 text-[#35C759]" />
            <span className="text-[11px] font-bold uppercase tracking-wider text-[#35C759]">
              Garden Center • Visão Geral da Loja
            </span>
          </div>
          <h3 className="text-xl lg:text-2xl font-black text-white tracking-tight">
            Desempenho Global do Faturamento
          </h3>
          <p className="text-xs text-[#8A8A8A] mt-1">
            Média histórica da loja: {formatCurrency(mediaHistorica)}/mês | Meta: {formatCurrency(config.metaLoja)} | Incremento necessário: {formatCurrency(config.metaLoja - mediaHistorica)} (+13,0%)
          </p>
        </div>

        <button
          onClick={onOpenNewEntry}
          className="px-4 py-2 rounded-xl bg-[#35C759] hover:bg-[#2db34e] text-black text-xs font-bold transition-all shadow-[0_0_15px_rgba(53,199,89,0.3)] shrink-0"
        >
          + Lançar Faturamento
        </button>
      </div>

      {/* Section 17 & 3: Indicador Principal de Meta */}
      <TargetGauge
        title="META TOTAL DA LOJA"
        meta={storeKpis.meta}
        realizado={storeKpis.realizado}
        statusRitmo={storeKpis.statusRitmo}
        ritmoAtual={storeKpis.ritmoAtual}
        ritmoNecessario={storeKpis.ritmoNecessario}
        projecao={storeKpis.projecao}
      />

      {/* Section 3: Regra de Remuneração da Gestão (Guilherme) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6 relative overflow-hidden">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-bold text-white tracking-tight">
                  Remuneração da Gestão (Guilherme)
                </h4>
                <p className="text-xs text-[#8A8A8A]">
                  Regra: {config.percentualRemuneracaoLoja}% sobre o valor que ultrapassar a média de {formatCurrency(mediaHistorica)}
                </p>
              </div>
            </div>

            <Badge variant={storeKpis.excedenteMedia > 0 ? 'positivo' : 'neutro'} size="sm">
              {storeKpis.excedenteMedia > 0 ? 'Excedente Ativo' : 'Aguardando Excedente'}
            </Badge>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-4">
            <div className="p-3.5 rounded-xl bg-black/40 border border-white/[0.06]">
              <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
                Média Histórica
              </span>
              <span className="text-lg font-bold text-white/90 block mt-0.5">
                {formatCurrency(mediaHistorica)}
              </span>
              <span className="text-[10px] text-[#8A8A8A] block">ponto de corte</span>
            </div>

            <div className="p-3.5 rounded-xl bg-black/40 border border-white/[0.06]">
              <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
                Excedente Atual
              </span>
              <span className="text-lg font-bold text-[#35C759] block mt-0.5">
                {formatCurrency(storeKpis.excedenteMedia)}
              </span>
              <span className="text-[10px] text-[#8A8A8A] block">acima da média</span>
            </div>

            <div className="p-3.5 rounded-xl bg-black/40 border border-white/[0.06]">
              <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
                Remuneração Atual
              </span>
              <span className="text-xl font-extrabold text-[#35C759] block mt-0.5">
                {formatCurrency(storeKpis.remuneracaoGestor)}
              </span>
              <span className="text-[10px] text-[#8A8A8A] block">2% sobre excedente</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.04] space-y-2 text-xs">
            <div className="flex justify-between items-center text-[#8A8A8A]">
              <span>Cálculo atual:</span>
              <span className="font-mono text-white">
                ({formatCurrency(storeKpis.realizado)} - {formatCurrency(mediaHistorica)}) × {config.percentualRemuneracaoLoja}%
              </span>
            </div>
            <div className="flex justify-between items-center text-[#8A8A8A] pt-1.5 border-t border-white/[0.04]">
              <span>Remuneração Projetada no Fechamento:</span>
              <span className="font-bold text-[#35C759] text-sm">
                {formatCurrency(storeKpis.remuneracaoProjetada)}
              </span>
            </div>
          </div>
        </div>

        {/* Simulador Interativo de Remuneração */}
        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Calculator className="w-4 h-4 text-[#F5C542]" />
              <h4 className="text-base font-bold text-white tracking-tight">
                Simulador de Remuneração
              </h4>
            </div>
            <p className="text-xs text-[#8A8A8A] mb-4">
              Arraste para simular o faturamento final da loja e ver a remuneração correspondente:
            </p>

            <div className="mb-4">
              <div className="flex justify-between items-center text-xs mb-1.5">
                <span className="text-[#8A8A8A]">Faturamento Simulado:</span>
                <span className="font-bold text-base text-white">
                  {formatCurrency(simulationRevenue)}
                </span>
              </div>
              <input
                type="range"
                min="350000"
                max="500000"
                step="5000"
                value={simulationRevenue}
                onChange={(e) => setSimulationRevenue(Number(e.target.value))}
                className="w-full accent-[#35C759] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#8A8A8A] mt-1 font-mono">
                <span>R$ 350.000</span>
                <span>R$ 400.000 (Meta)</span>
                <span>R$ 500.000</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06] flex items-center justify-between">
              <div>
                <span className="text-[11px] text-[#8A8A8A] uppercase font-semibold block">
                  Remuneração Estimada:
                </span>
                <span className="text-2xl font-black text-[#35C759]">
                  {formatCurrency(simuladoRemuneracao)}
                </span>
              </div>
              <div className="text-right text-xs text-[#8A8A8A]">
                <span>Excedente: </span>
                <span className="font-semibold text-white">
                  {formatCurrency(simuladoExcedente)}
                </span>
              </div>
            </div>
          </div>

          <p className="text-[11px] text-[#8A8A8A] mt-4 pt-3 border-t border-white/[0.04]">
            💡 Exemplo da Seção 3: Com R$ 400.000, excedente de R$ 46.000 × 2% = <strong>R$ 920,00</strong>.
          </p>
        </div>
      </div>

      {/* Divisão dos Canais: Equipe vs Balcão */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6">
        <h4 className="text-base font-bold text-white tracking-tight mb-4">
          Composição da Receita por Canal da Loja
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Vendas da Equipe Comercial
              </span>
              <span className="text-xs font-semibold text-[#35C759]">
                {formatPercent(storeKpis.realizado > 0 ? (teamTotal / storeKpis.realizado) * 100 : 0)} do total
              </span>
            </div>
            <span className="text-2xl font-extrabold text-white block">
              {formatCurrency(teamTotal)}
            </span>
            <p className="text-xs text-[#8A8A8A] mt-1">
              Alessandra, Felipe e Arnaldo (Meta: {formatCurrency(config.metaEquipe)})
            </p>
          </div>

          <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Caixa Central / Balcão / Outros
              </span>
              <span className="text-xs font-semibold text-blue-400">
                {formatPercent(storeKpis.realizado > 0 ? (balcaoTotal / storeKpis.realizado) * 100 : 0)} do total
              </span>
            </div>
            <span className="text-2xl font-extrabold text-white block">
              {formatCurrency(balcaoTotal)}
            </span>
            <p className="text-xs text-[#8A8A8A] mt-1">
              Vendas diretas de balcão, caixa rápido e autosserviço
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
