import React, { useState } from 'react';
import { SaleEntry, Seller } from '../../types';
import { formatCurrency, formatDateBr, formatNumber } from '../../utils/formatters';
import { calculateTicket } from '../../utils/calculations';
import { Modal } from '../Common/Modal';
import { Badge } from '../Common/Badge';
import { clsx } from 'clsx';
import {
  Plus,
  Search,
  Filter,
  Trash2,
  Edit2,
  FileSpreadsheet,
  Download,
  Upload,
  CheckCircle2,
  Sparkles,
  Calendar,
  User,
  DollarSign,
  ShoppingBag,
  ArrowUpDown,
} from 'lucide-react';
import { dataService } from '../../services/dataService';

interface EntriesManagerProps {
  entries: SaleEntry[];
  sellers: Seller[];
  onAddEntry: (entry: Omit<SaleEntry, 'id' | 'ticketMedio' | 'createdAt'>) => void;
  onUpdateEntry: (id: string, partial: Partial<SaleEntry>) => void;
  onDeleteEntry: (id: string) => void;
  onRefresh: () => void;
}

export const EntriesManager: React.FC<EntriesManagerProps> = ({
  entries,
  sellers,
  onAddEntry,
  onUpdateEntry,
  onDeleteEntry,
  onRefresh,
}) => {
  // Filters & State
  const [searchTerm, setSearchTerm] = useState('');
  const [sellerFilter, setSellerFilter] = useState('todos');
  const [sortField, setSortField] = useState<'data' | 'faturamento' | 'numVendas' | 'ticketMedio'>('data');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12;

  // Modals
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<SaleEntry | null>(null);
  const [entryToDelete, setEntryToDelete] = useState<SaleEntry | null>(null);

  // Form states
  const [formData, setFormData] = useState({
    data: '2026-09-24',
    vendedor: 'Arnaldo',
    faturamento: '12568.30',
    numVendas: '100',
    observacao: '',
  });

  // Calculate live ticket
  const parsedFaturamento = parseFloat(formData.faturamento) || 0;
  const parsedVendas = parseInt(formData.numVendas, 10) || 0;
  const liveTicket = calculateTicket(parsedFaturamento, parsedVendas);

  const resetForm = () => {
    setFormData({
      data: '2026-09-24',
      vendedor: sellers[0]?.nome || 'Arnaldo',
      faturamento: '',
      numVendas: '',
      observacao: '',
    });
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.faturamento || !formData.numVendas) return;

    onAddEntry({
      data: formData.data,
      vendedor: formData.vendedor,
      faturamento: parsedFaturamento,
      numVendas: parsedVendas,
      observacao: formData.observacao,
      origem: 'manual',
    });

    setIsNewModalOpen(false);
    resetForm();
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEntry) return;

    onUpdateEntry(editingEntry.id, {
      data: formData.data,
      vendedor: formData.vendedor,
      faturamento: parsedFaturamento,
      numVendas: parsedVendas,
      observacao: formData.observacao,
    });

    setEditingEntry(null);
    resetForm();
  };

  const openEdit = (entry: SaleEntry) => {
    setEditingEntry(entry);
    setFormData({
      data: entry.data,
      vendedor: entry.vendedor,
      faturamento: String(entry.faturamento),
      numVendas: String(entry.numVendas),
      observacao: entry.observacao || '',
    });
  };

  // Section 45: Quick validation test case
  const fillValidationTest = () => {
    setFormData({
      data: '2026-09-24',
      vendedor: 'Arnaldo',
      faturamento: '12568.30',
      numVendas: '100',
      observacao: 'Validação oficial Seção 45 (Ticket esperado: R$ 125,68)',
    });
  };

  // Filter and sort entries
  const filteredEntries = entries
    .filter((entry) => {
      const matchSeller =
        sellerFilter === 'todos' || entry.vendedor.toLowerCase() === sellerFilter.toLowerCase();
      const matchSearch =
        entry.vendedor.toLowerCase().includes(searchTerm.toLowerCase()) ||
        entry.data.includes(searchTerm) ||
        (entry.observacao && entry.observacao.toLowerCase().includes(searchTerm.toLowerCase()));
      return matchSeller && matchSearch;
    })
    .sort((a, b) => {
      let comparison = 0;
      if (sortField === 'data') {
        comparison = a.data.localeCompare(b.data);
      } else if (sortField === 'faturamento') {
        comparison = a.faturamento - b.faturamento;
      } else if (sortField === 'numVendas') {
        comparison = a.numVendas - b.numVendas;
      } else if (sortField === 'ticketMedio') {
        comparison = a.ticketMedio - b.ticketMedio;
      }
      return sortOrder === 'desc' ? -comparison : comparison;
    });

  const totalPages = Math.ceil(filteredEntries.length / itemsPerPage);
  const paginatedEntries = filteredEntries.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const toggleSort = (field: typeof sortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  // CSV Export & Download
  const handleExportCsv = () => {
    const csvContent = dataService.exportSalesCsv();
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `DADOS_VENDAS_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Top Action Bar */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-5 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold text-white tracking-tight">
            Lançamentos de Vendas Diárias
          </h3>
          <p className="text-xs text-[#8A8A8A]">
            Base operacional do Garden Center • Cálculo automático de ticket médio
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap self-end md:self-auto">
          {/* Section 45 Test Button */}
          <button
            onClick={() => {
              fillValidationTest();
              setIsNewModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/20 text-xs font-semibold transition-all"
            title="Preencher teste da Seção 45 (Arnaldo 24/09: R$ 12.568,30 / 100 vendas)"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>Testar Lançamento (Seção 45)</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-white border border-white/[0.08] text-xs font-semibold transition-all"
            title="Exportar no formato da planilha Google Sheets DADOS_VENDAS"
          >
            <Download className="w-3.5 h-3.5 text-[#35C759]" />
            <span>Exportar CSV</span>
          </button>

          <button
            onClick={() => {
              resetForm();
              setIsNewModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#35C759] hover:bg-[#2db34e] text-black text-xs font-bold transition-all shadow-[0_0_15px_rgba(53,199,89,0.3)]"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>Novo Lançamento</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-[#8A8A8A] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Buscar por vendedor, data ou nota..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 bg-black/40 border border-white/[0.08] rounded-xl text-xs text-white placeholder-[#8A8A8A] focus:outline-none focus:border-[#35C759]"
          />
        </div>

        {/* Seller Filter */}
        <div className="relative">
          <select
            value={sellerFilter}
            onChange={(e) => setSellerFilter(e.target.value)}
            className="w-full px-4 py-2 bg-black/40 border border-white/[0.08] rounded-xl text-xs text-white focus:outline-none focus:border-[#35C759] appearance-none"
          >
            <option value="todos">Todos os Vendedores e Canais</option>
            {sellers.map((s) => (
              <option key={s.id} value={s.nome}>
                {s.nome}
              </option>
            ))}
          </select>
          <Filter className="w-3.5 h-3.5 text-[#8A8A8A] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>

        {/* Count summary */}
        <div className="flex items-center justify-between px-4 py-2 bg-white/[0.02] border border-white/[0.06] rounded-xl text-xs text-[#8A8A8A]">
          <span>Lançamentos encontrados:</span>
          <span className="font-bold text-white font-mono">{filteredEntries.length}</span>
        </div>
      </div>

      {/* Table of Entries */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/[0.08] text-[#8A8A8A] uppercase font-semibold tracking-wider bg-white/[0.01]">
                <th
                  className="py-3 px-4 cursor-pointer hover:text-white"
                  onClick={() => toggleSort('data')}
                >
                  <div className="flex items-center gap-1.5">
                    <span>Data</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4">Vendedor</th>
                <th
                  className="py-3 px-4 cursor-pointer hover:text-white"
                  onClick={() => toggleSort('faturamento')}
                >
                  <div className="flex items-center gap-1.5">
                    <span>Faturamento</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  className="py-3 px-4 cursor-pointer hover:text-white"
                  onClick={() => toggleSort('numVendas')}
                >
                  <div className="flex items-center gap-1.5">
                    <span>Nº Vendas</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th
                  className="py-3 px-4 cursor-pointer hover:text-white"
                  onClick={() => toggleSort('ticketMedio')}
                >
                  <div className="flex items-center gap-1.5">
                    <span>Ticket Médio (Auto)</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4">Origem / Obs</th>
                <th className="py-3 px-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {paginatedEntries.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-[#8A8A8A]">
                    <div className="flex flex-col items-center justify-center gap-2">
                      <FileSpreadsheet className="w-8 h-8 opacity-40" />
                      <p className="font-semibold text-white">Nenhum lançamento encontrado</p>
                      <p className="text-xs">Insira um novo lançamento acima ou limpe os filtros.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                paginatedEntries.map((entry) => (
                  <tr key={entry.id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-4 font-mono text-white/90 font-medium">
                      {formatDateBr(entry.data)}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-white flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#35C759]" />
                      {entry.vendedor}
                    </td>
                    <td className="py-3.5 px-4 font-extrabold text-white">
                      {formatCurrency(entry.faturamento)}
                    </td>
                    <td className="py-3.5 px-4 text-white/80 font-mono">
                      {formatNumber(entry.numVendas)}
                    </td>
                    <td className="py-3.5 px-4 font-bold text-[#35C759] font-mono">
                      {formatCurrency(entry.ticketMedio)}
                    </td>
                    <td className="py-3.5 px-4 text-[11px] text-[#8A8A8A] max-w-[200px] truncate">
                      {entry.observacao || (
                        <span className="opacity-50">
                          {entry.origem === 'demo' ? 'Demonstração' : 'Lançamento manual'}
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => openEdit(entry)}
                          className="p-1.5 rounded-lg text-[#8A8A8A] hover:text-white hover:bg-white/[0.06] transition-colors"
                          title="Editar lançamento"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setEntryToDelete(entry)}
                          className="p-1.5 rounded-lg text-[#8A8A8A] hover:text-[#FF453A] hover:bg-[#FF453A]/10 transition-colors"
                          title="Excluir lançamento"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="p-4 border-t border-white/[0.08] flex items-center justify-between text-xs text-[#8A8A8A]">
            <span>
              Página {currentPage} de {totalPages} ({filteredEntries.length} itens)
            </span>
            <div className="flex items-center gap-1">
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                className="px-2.5 py-1 rounded-lg bg-black/40 border border-white/[0.08] text-white disabled:opacity-30"
              >
                Anterior
              </button>
              <button
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                className="px-2.5 py-1 rounded-lg bg-black/40 border border-white/[0.08] text-white disabled:opacity-30"
              >
                Próxima
              </button>
            </div>
          </div>
        )}
      </div>

      {/* MODAL: NOVO LANÇAMENTO (Seção 34 & 35) */}
      <Modal
        isOpen={isNewModalOpen}
        onClose={() => setIsNewModalOpen(false)}
        title="Novo Lançamento Comercial"
        subtitle="Informe faturamento e vendas — o Ticket Médio é calculado automaticamente."
      >
        <form onSubmit={handleCreateSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1">
              Data do Lançamento
            </label>
            <input
              type="date"
              required
              value={formData.data}
              onChange={(e) => setFormData({ ...formData, data: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-[#35C759]"
            />
          </div>

          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1">
              Vendedor / Canal
            </label>
            <select
              value={formData.vendedor}
              onChange={(e) => setFormData({ ...formData, vendedor: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-[#35C759]"
            >
              {sellers.map((s) => (
                <option key={s.id} value={s.nome}>
                  {s.nome}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1">
                Faturamento (R$)
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                required
                placeholder="Ex: 12568.30"
                value={formData.faturamento}
                onChange={(e) => setFormData({ ...formData, faturamento: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
              />
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1">
                Número de Vendas
              </label>
              <input
                type="number"
                min="1"
                required
                placeholder="Ex: 100"
                value={formData.numVendas}
                onChange={(e) => setFormData({ ...formData, numVendas: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
              />
            </div>
          </div>

          {/* Section 35: Live Ticket Médio Calculation */}
          <div className="p-3.5 rounded-xl bg-black/40 border border-[#35C759]/30 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#8A8A8A] block">
                Ticket Médio (Automático)
              </span>
              <span className="text-xl font-extrabold text-[#35C759] font-mono">
                {formatCurrency(liveTicket)}
              </span>
            </div>
            <span className="text-xs text-[#8A8A8A] font-medium text-right">
              {parsedVendas > 0 ? `${formatCurrency(parsedFaturamento)} ÷ ${parsedVendas} vendas` : 'Aguardando valores'}
            </span>
          </div>

          <div>
            <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1">
              Observação (Opcional)
            </label>
            <input
              type="text"
              placeholder="Ex: Dia com evento de orquídeas"
              value={formData.observacao}
              onChange={(e) => setFormData({ ...formData, observacao: e.target.value })}
              className="w-full px-3.5 py-2 bg-black/60 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#35C759]"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/[0.08]">
            <button
              type="button"
              onClick={() => setIsNewModalOpen(false)}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-[#8A8A8A] hover:text-white transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-[#35C759] hover:bg-[#2db34e] text-black text-xs font-bold transition-all shadow-[0_0_15px_rgba(53,199,89,0.3)]"
            >
              SALVAR LANÇAMENTO
            </button>
          </div>
        </form>
      </Modal>

      {/* MODAL: EDITAR LANÇAMENTO */}
      {editingEntry && (
        <Modal
          isOpen={!!editingEntry}
          onClose={() => setEditingEntry(null)}
          title="Editar Lançamento"
          subtitle="Modifique os valores do lançamento selecionado."
        >
          <form onSubmit={handleEditSubmit} className="space-y-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1">
                Data
              </label>
              <input
                type="date"
                required
                value={formData.data}
                onChange={(e) => setFormData({ ...formData, data: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-[#35C759]"
              />
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1">
                Vendedor
              </label>
              <select
                value={formData.vendedor}
                onChange={(e) => setFormData({ ...formData, vendedor: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-[#35C759]"
              >
                {sellers.map((s) => (
                  <option key={s.id} value={s.nome}>
                    {s.nome}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1">
                  Faturamento (R$)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  required
                  value={formData.faturamento}
                  onChange={(e) => setFormData({ ...formData, faturamento: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1">
                  Nº Vendas
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={formData.numVendas}
                  onChange={(e) => setFormData({ ...formData, numVendas: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
                />
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-black/40 border border-[#35C759]/30 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#8A8A8A] block">
                  Ticket Médio Atualizado
                </span>
                <span className="text-xl font-extrabold text-[#35C759] font-mono">
                  {formatCurrency(liveTicket)}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/[0.08]">
              <button
                type="button"
                onClick={() => setEditingEntry(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-[#8A8A8A] hover:text-white transition-colors"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-xl bg-[#35C759] hover:bg-[#2db34e] text-black text-xs font-bold transition-all shadow-[0_0_15px_rgba(53,199,89,0.3)]"
              >
                SALVAR ALTERAÇÕES
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* CONFIRMAÇÃO DE EXCLUSÃO */}
      {entryToDelete && (
        <Modal
          isOpen={!!entryToDelete}
          onClose={() => setEntryToDelete(null)}
          title="Excluir Lançamento"
          subtitle="Tem certeza que deseja excluir permanentemente este lançamento?"
        >
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-black/40 border border-[#FF453A]/30">
              <p className="text-sm font-semibold text-white">
                {entryToDelete.vendedor} — {formatDateBr(entryToDelete.data)}
              </p>
              <p className="text-xs text-[#8A8A8A] mt-1">
                Faturamento: {formatCurrency(entryToDelete.faturamento)} | {entryToDelete.numVendas} vendas | Ticket: {formatCurrency(entryToDelete.ticketMedio)}
              </p>
            </div>

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/[0.08]">
              <button
                type="button"
                onClick={() => setEntryToDelete(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-[#8A8A8A] hover:text-white transition-colors"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteEntry(entryToDelete.id);
                  setEntryToDelete(null);
                }}
                className="px-5 py-2 rounded-xl bg-[#FF453A] hover:bg-red-600 text-white text-xs font-bold transition-all"
              >
                Sim, Excluir
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
