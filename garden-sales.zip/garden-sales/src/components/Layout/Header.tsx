import React from 'react';
import { Menu, Calendar, RefreshCw, Plus, Clock, FileSpreadsheet, Eye } from 'lucide-react';
import { PageId, RoleMode } from '../../types';
import { clsx } from 'clsx';

interface HeaderProps {
  currentPage: PageId;
  roleMode: RoleMode;
  onOpenMobileMenu: () => void;
  onOpenNewEntry: () => void;
  onOpenTodayModal: () => void;
  onOpenSheetsModal: () => void;
  onRefreshData: () => void;
  isRefreshing: boolean;
  diasDecorridos: number;
  diasOperacionais: number;
  mesReferenciaNome: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  roleMode,
  onOpenMobileMenu,
  onOpenNewEntry,
  onOpenTodayModal,
  onOpenSheetsModal,
  onRefreshData,
  isRefreshing,
  diasDecorridos,
  diasOperacionais,
  mesReferenciaNome,
}) => {
  const getPageTitle = () => {
    switch (currentPage) {
      case 'dashboard':
        return 'Dashboard Executivo';
      case 'equipe':
        return 'Painel da Equipe de Vendas';
      case 'vendedores':
        return 'Desempenho Individual dos Vendedores';
      case 'loja':
        return 'Painel Comercial da Loja';
      case 'lancamentos':
        return 'Gestão de Lançamentos de Vendas';
      case 'metas':
        return 'Acompanhamento e Quebra de Metas';
      case 'analises':
        return 'Análises Comerciais e Ticket Médio';
      case 'configuracoes':
        return 'Configurações do Sistema';
      default:
        return 'GARDEN SALES';
    }
  };

  const getRoleLabel = () => {
    switch (roleMode) {
      case 'vendedores':
        return { label: 'Modo Vendedores (Coletivo)', badge: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' };
      case 'diretoria':
        return { label: 'Modo Diretoria Executiva', badge: 'bg-amber-500/10 text-amber-400 border-amber-500/20' };
      case 'guilherme':
      default:
        return { label: 'Modo Gestão (Guilherme)', badge: 'bg-[#35C759]/10 text-[#35C759] border-[#35C759]/20' };
    }
  };

  const roleInfo = getRoleLabel();

  return (
    <header className="sticky top-0 z-30 bg-[#050505]/90 backdrop-blur-md border-b border-white/[0.08] px-4 lg:px-8 py-3.5 transition-all">
      <div className="flex items-center justify-between gap-4">
        {/* Left: Mobile Toggle + Title + Breadcrumbs */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenMobileMenu}
            className="p-2 -ml-2 rounded-lg text-[#8A8A8A] hover:text-white hover:bg-white/[0.06] lg:hidden"
            aria-label="Abrir menu lateral"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base lg:text-lg font-bold text-white tracking-tight">
                {getPageTitle()}
              </h2>
              <span className={clsx('text-[10px] font-semibold px-2 py-0.5 rounded-full border hidden sm:inline-block', roleInfo.badge)}>
                {roleInfo.label}
              </span>
            </div>

            <div className="flex items-center gap-2 text-xs text-[#8A8A8A] mt-0.5">
              <span className="flex items-center gap-1 font-medium">
                <Calendar className="w-3.5 h-3.5 text-[#35C759]" />
                {mesReferenciaNome}
              </span>
              <span>•</span>
              <span className="font-mono text-[11px]">
                {diasDecorridos} de {diasOperacionais} dias operacionais
              </span>
            </div>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          {/* Button: Visão Hoje (#33) */}
          <button
            onClick={onOpenTodayModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] text-white border border-white/[0.08] text-xs font-medium transition-all"
            title="Abrir resumo da performance do dia"
          >
            <Clock className="w-3.5 h-3.5 text-[#F5C542]" />
            <span className="hidden sm:inline">Visão Hoje</span>
          </button>

          {/* Button: Google Sheets (#36-38) */}
          <button
            onClick={onOpenSheetsModal}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] text-[#8A8A8A] hover:text-white border border-white/[0.08] text-xs font-medium transition-all hidden md:flex"
            title="Conectar e sincronizar com Google Sheets"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-[#35C759]" />
            <span>Sheets</span>
          </button>

          {/* Button: Atualizar Dados (#38) */}
          <button
            onClick={onRefreshData}
            disabled={isRefreshing}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] text-white border border-white/[0.08] text-xs font-medium transition-all disabled:opacity-50"
            title="Recalcular todos os indicadores e atualizar gráficos"
          >
            <RefreshCw className={clsx('w-3.5 h-3.5', isRefreshing && 'animate-spin text-[#35C759]')} />
            <span className="hidden sm:inline">Atualizar</span>
          </button>

          {/* Button: Novo Lançamento */}
          <button
            onClick={onOpenNewEntry}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#35C759] hover:bg-[#2db34e] text-black font-semibold text-xs tracking-tight shadow-[0_0_15px_rgba(53,199,89,0.25)] transition-all"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span className="hidden sm:inline">Novo Lançamento</span>
            <span className="sm:hidden">Lançar</span>
          </button>
        </div>
      </div>
    </header>
  );
};
