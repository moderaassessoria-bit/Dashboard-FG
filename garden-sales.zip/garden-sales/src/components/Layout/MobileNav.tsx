import React from 'react';
import { LayoutDashboard, Users, UserCheck, Store, Plus, FileSpreadsheet } from 'lucide-react';
import { PageId, RoleMode } from '../../types';
import { clsx } from 'clsx';

interface MobileNavProps {
  currentPage: PageId;
  onPageChange: (page: PageId) => void;
  onOpenNewEntry: () => void;
  roleMode: RoleMode;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  currentPage,
  onPageChange,
  onOpenNewEntry,
  roleMode,
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#0a0a0a]/95 backdrop-blur-md border-t border-white/[0.08] px-3 py-2 lg:hidden flex items-center justify-around">
      <button
        onClick={() => onPageChange('dashboard')}
        className={clsx(
          'flex flex-col items-center gap-1 text-[10px] font-medium transition-colors',
          currentPage === 'dashboard' ? 'text-[#35C759]' : 'text-[#8A8A8A]'
        )}
      >
        <LayoutDashboard className="w-5 h-5" />
        <span>Início</span>
      </button>

      <button
        onClick={() => onPageChange('equipe')}
        className={clsx(
          'flex flex-col items-center gap-1 text-[10px] font-medium transition-colors',
          currentPage === 'equipe' ? 'text-[#35C759]' : 'text-[#8A8A8A]'
        )}
      >
        <Users className="w-5 h-5" />
        <span>Equipe</span>
      </button>

      {/* Floating Center Action Button */}
      <button
        onClick={onOpenNewEntry}
        className="w-11 h-11 -mt-5 rounded-full bg-[#35C759] text-black flex items-center justify-center shadow-[0_0_15px_rgba(53,199,89,0.5)] border-2 border-[#0a0a0a]"
        aria-label="Novo Lançamento"
      >
        <Plus className="w-6 h-6 stroke-[2.5]" />
      </button>

      {roleMode !== 'vendedores' ? (
        <button
          onClick={() => onPageChange('vendedores')}
          className={clsx(
            'flex flex-col items-center gap-1 text-[10px] font-medium transition-colors',
            currentPage === 'vendedores' ? 'text-[#35C759]' : 'text-[#8A8A8A]'
          )}
        >
          <UserCheck className="w-5 h-5" />
          <span>Vendedores</span>
        </button>
      ) : (
        <button
          onClick={() => onPageChange('metas')}
          className={clsx(
            'flex flex-col items-center gap-1 text-[10px] font-medium transition-colors',
            currentPage === 'metas' ? 'text-[#35C759]' : 'text-[#8A8A8A]'
          )}
        >
          <Store className="w-5 h-5" />
          <span>Metas</span>
        </button>
      )}

      <button
        onClick={() => onPageChange('lancamentos')}
        className={clsx(
          'flex flex-col items-center gap-1 text-[10px] font-medium transition-colors',
          currentPage === 'lancamentos' ? 'text-[#35C759]' : 'text-[#8A8A8A]'
        )}
      >
        <FileSpreadsheet className="w-5 h-5" />
        <span>Lançar</span>
      </button>
    </div>
  );
};
