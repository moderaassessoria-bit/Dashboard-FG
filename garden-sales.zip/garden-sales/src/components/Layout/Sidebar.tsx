import React from 'react';
import {
  LayoutDashboard,
  Users,
  UserCheck,
  Store,
  PlusCircle,
  FileSpreadsheet,
  Target,
  BarChart3,
  Settings,
  RefreshCw,
  Sparkles,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react';
import { PageId, RoleMode } from '../../types';
import { clsx } from 'clsx';

interface SidebarProps {
  currentPage: PageId;
  onPageChange: (page: PageId) => void;
  roleMode: RoleMode;
  onRoleModeChange: (mode: RoleMode) => void;
  onOpenNewEntry: () => void;
  onRefreshData: () => void;
  isRefreshing: boolean;
  lastSyncTime: string;
  isMobileOpen?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onPageChange,
  roleMode,
  onRoleModeChange,
  onOpenNewEntry,
  onRefreshData,
  isRefreshing,
  lastSyncTime,
  isMobileOpen,
  onCloseMobile,
}) => {
  const navItems = [
    {
      id: 'dashboard' as PageId,
      label: 'Dashboard Executivo',
      icon: LayoutDashboard,
      allowedRoles: ['guilherme', 'diretoria', 'vendedores'],
    },
    {
      id: 'equipe' as PageId,
      label: 'Equipe',
      icon: Users,
      badge: 'R$ 155k',
      allowedRoles: ['guilherme', 'diretoria', 'vendedores'],
    },
    {
      id: 'vendedores' as PageId,
      label: 'Vendedores',
      icon: UserCheck,
      allowedRoles: ['guilherme', 'diretoria'], // Section 4: Public team view hides individual
    },
    {
      id: 'loja' as PageId,
      label: 'Loja',
      icon: Store,
      badge: 'R$ 400k',
      allowedRoles: ['guilherme', 'diretoria'],
    },
    {
      id: 'lancamentos' as PageId,
      label: 'Lançamentos',
      icon: FileSpreadsheet,
      allowedRoles: ['guilherme', 'diretoria', 'vendedores'],
    },
    {
      id: 'metas' as PageId,
      label: 'Metas',
      icon: Target,
      allowedRoles: ['guilherme', 'diretoria', 'vendedores'],
    },
    {
      id: 'analises' as PageId,
      label: 'Análises',
      icon: BarChart3,
      allowedRoles: ['guilherme', 'diretoria'],
    },
    {
      id: 'configuracoes' as PageId,
      label: 'Configurações',
      icon: Settings,
      allowedRoles: ['guilherme', 'diretoria'],
    },
  ];

  const filteredNavItems = navItems.filter((item) =>
    item.allowedRoles.includes(roleMode)
  );

  return (
    <>
      {/* Mobile backdrop */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={clsx(
          'fixed top-0 bottom-0 left-0 z-50 w-64 bg-[#0a0a0a] border-r border-white/[0.08] flex flex-col transition-transform duration-300 ease-in-out',
          isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Brand Header */}
        <div className="p-5 border-b border-white/[0.08] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#1F8F4C] to-[#35C759] flex items-center justify-center shadow-[0_0_15px_rgba(53,199,89,0.35)]">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-sm tracking-wide text-white flex items-center gap-1.5">
                GARDEN SALES
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#35C759]/20 text-[#35C759] font-mono border border-[#35C759]/30">
                  PRO
                </span>
              </h1>
              <p className="text-[11px] text-[#8A8A8A] font-medium tracking-tight">
                Gestão Comercial
              </p>
            </div>
          </div>
        </div>

        {/* User Card & Role Switcher */}
        <div className="p-3 mx-3 my-3 rounded-xl bg-white/[0.03] border border-white/[0.06]">
          <div className="flex items-center gap-2.5 mb-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-emerald-600 to-teal-800 flex items-center justify-center text-xs font-bold text-white shadow-sm">
              G
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-semibold text-white leading-none truncate">
                Guilherme
              </p>
              <p className="text-[10px] text-[#8A8A8A] mt-0.5 truncate">
                Líder de Vendas
              </p>
            </div>
          </div>

          {/* Mode Selector */}
          <div>
            <label className="text-[9px] uppercase tracking-wider text-[#8A8A8A] font-semibold block mb-1">
              Modo de Visualização:
            </label>
            <div className="grid grid-cols-3 gap-1 bg-black/40 p-0.5 rounded-lg border border-white/[0.04]">
              <button
                type="button"
                onClick={() => onRoleModeChange('guilherme')}
                className={clsx(
                  'text-[10px] py-1 rounded font-medium transition-all',
                  roleMode === 'guilherme'
                    ? 'bg-[#35C759]/20 text-[#35C759] font-semibold border border-[#35C759]/30'
                    : 'text-[#8A8A8A] hover:text-white'
                )}
                title="Modo Guilherme: Visão completa de líder"
              >
                Líder
              </button>
              <button
                type="button"
                onClick={() => onRoleModeChange('vendedores')}
                className={clsx(
                  'text-[10px] py-1 rounded font-medium transition-all',
                  roleMode === 'vendedores'
                    ? 'bg-[#35C759]/20 text-[#35C759] font-semibold border border-[#35C759]/30'
                    : 'text-[#8A8A8A] hover:text-white'
                )}
                title="Modo Vendedores: Visão coletiva sem expor individual"
              >
                Equipe
              </button>
              <button
                type="button"
                onClick={() => onRoleModeChange('diretoria')}
                className={clsx(
                  'text-[10px] py-1 rounded font-medium transition-all',
                  roleMode === 'diretoria'
                    ? 'bg-[#35C759]/20 text-[#35C759] font-semibold border border-[#35C759]/30'
                    : 'text-[#8A8A8A] hover:text-white'
                )}
                title="Modo Diretoria: Foco executivo e remuneração"
              >
                Diretoria
              </button>
            </div>
          </div>
        </div>

        {/* Quick Action Button */}
        <div className="px-3 mb-2">
          <button
            onClick={() => {
              onOpenNewEntry();
              if (onCloseMobile) onCloseMobile();
            }}
            className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-[#35C759] hover:bg-[#2db34e] text-black font-semibold text-xs tracking-tight shadow-[0_0_15px_rgba(53,199,89,0.3)] transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <PlusCircle className="w-4 h-4 text-black" />
            <span>Novo Lançamento</span>
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 px-2.5 py-1 space-y-0.5 overflow-y-auto">
          {filteredNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onPageChange(item.id);
                  if (onCloseMobile) onCloseMobile();
                }}
                className={clsx(
                  'w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-all duration-200 group text-left',
                  isActive
                    ? 'bg-white/[0.08] text-white border-l-2 border-[#35C759] font-semibold pl-2.5'
                    : 'text-[#8A8A8A] hover:text-white hover:bg-white/[0.04]'
                )}
              >
                <div className="flex items-center gap-2.5">
                  <Icon
                    className={clsx(
                      'w-4 h-4 transition-colors',
                      isActive ? 'text-[#35C759]' : 'text-[#8A8A8A] group-hover:text-white'
                    )}
                  />
                  <span>{item.label}</span>
                </div>
                {item.badge && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/[0.06] text-[#8A8A8A] group-hover:text-white">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom Sync & Status */}
        <div className="p-3 border-t border-white/[0.08] bg-[#070707]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] font-medium text-[#8A8A8A] flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#35C759] animate-pulse" />
              Sincronizado
            </span>
            <button
              onClick={onRefreshData}
              disabled={isRefreshing}
              className="p-1 rounded text-[#8A8A8A] hover:text-white hover:bg-white/[0.06] transition-all disabled:opacity-50"
              title="Recalcular e atualizar dados"
            >
              <RefreshCw className={clsx('w-3.5 h-3.5', isRefreshing && 'animate-spin text-[#35C759]')} />
            </button>
          </div>
          <p className="text-[10px] text-[#8A8A8A] truncate font-mono">
            Atualizado: {lastSyncTime}
          </p>
        </div>
      </aside>
    </>
  );
};
