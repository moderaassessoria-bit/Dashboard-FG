import React, { useState } from 'react';
import {
  StoreKpis,
  TeamKpis,
  SellerPerformance,
  SystemConfig,
  SaleEntry,
} from '../../types';
import { formatCurrency, formatPercent, formatNumber } from '../../utils/formatters';
import { WeeklyBreakdownCard } from '../Dashboard/WeeklyBreakdownCard';
import { computeWeeklyBreakdown, computeDailyAccumulated } from '../../utils/calculations';
import { clsx } from 'clsx';
import {
  Target,
  Flame,
  Calendar,
  Layers,
  ArrowUpRight,
  TrendingDown,
  TrendingUp,
  Clock,
  Sparkles,
} from 'lucide-react';

interface GoalsDashboardProps {
  storeKpis: StoreKpis;
  teamKpis: TeamKpis;
  sellerPerformances: SellerPerformance[];
  config: SystemConfig;
  entries: SaleEntry[];
}

export const GoalsDashboard: React.FC<GoalsDashboardProps> = ({
  storeKpis,
  teamKpis,
  sellerPerformances,
  config,
  entries,
}) => {
  const [activeTab, setActiveTab] = useState<'loja' | 'equipe'>('loja');

  const teamSellerNames = ['alessandra', 'felipe', 'arnaldo'];
  const teamEntries = entries.filter((e) =>
    teamSellerNames.includes(e.vendedor.toLowerCase())
  );

  const activeEntries = activeTab === 'loja' ? entries : teamEntries;
  const weekly = computeWeeklyBreakdown(activeEntries, config, activeTab);
  const dailyPace = computeDailyAccumulated(activeEntries, config, activeTab);

  const activeKpis = activeTab === 'loja' ? storeKpis : teamKpis;

  // Filter team sellers only
  const teamSellersOnly = sellerPerformances.filter((s) =>
    teamSellerNames.includes(s.nome.toLowerCase())
  );

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Switcher Tab: Loja vs Equipe */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold text-white tracking-tight">
            Gestão e Acompanhamento de Metas
          </h3>
          <p className="text-xs text-[#8A8A8A]">
            Quebra diária, semanal e ritmo necessário para fechamento
          </p>
        </div>

        <div className="flex items-center bg-black/40 p-1 rounded-xl border border-white/[0.06]">
          <button
            onClick={() => setActiveTab('loja')}
            className={clsx(
              'px-4 py-2 rounded-lg text-xs font-bold transition-all',
              activeTab === 'loja'
                ? 'bg-[#35C759] text-black shadow-[0_0_12px_rgba(53,199,89,0.3)]'
                : 'text-[#8A8A8A] hover:text-white'
            )}
          >
            Meta da Loja (R$ 400k)
          </button>
          <button
            onClick={() => setActiveTab('equipe')}
            className={clsx(
              'px-4 py-2 rounded-lg text-xs font-bold transition-all',
              activeTab === 'equipe'
                ? 'bg-[#35C759] text-black shadow-[0_0_12px_rgba(53,199,89,0.3)]'
                : 'text-[#8A8A8A] hover:text-white'
            )}
          >
            Meta da Equipe (R$ 155k)
          </button>
        </div>
      </div>

      {/* Section 32: Card de Grande Destaque "QUANTO PRECISO VENDER POR DIA?" */}
      <div className="rounded-2xl border border-[#35C759]/40 bg-gradient-to-br from-[#35C759]/10 via-black to-[#35C759]/5 p-6 shadow-[0_0_25px_rgba(53,199,89,0.15)] relative overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-[#35C759]/20 text-[#35C759]">
              <Flame className="w-5 h-5 text-[#35C759]" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-[#35C759] uppercase tracking-wider block">
                Foco Diário de Ação Comercial
              </span>
              <h4 className="text-lg font-bold text-white">
                QUANTO PRECISO VENDER POR DIA?
              </h4>
            </div>
          </div>

          <span className="px-3 py-1 rounded-full text-xs font-bold bg-black/50 border border-white/10 text-white font-mono">
            {storeKpis.diasRestantes} dias operacionais restantes
          </span>
        </div>

        {/* 3 Prominent Columns: Loja, Equipe, Cada Vendedor */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-2">
          {/* Loja */}
          <div className="p-4 rounded-xl bg-black/50 border border-white/[0.08]">
            <span className="text-xs text-[#8A8A8A] uppercase font-semibold block mb-1">
              Para a Loja Bater R$ 400.000
            </span>
            <span className="text-2xl lg:text-3xl font-black text-white block">
              {storeKpis.falta > 0 ? `${formatCurrency(storeKpis.ritmoNecessario)}/dia` : 'Meta Conquistada! 🎉'}
            </span>
            <p className="text-xs text-[#8A8A8A] mt-2 pt-2 border-t border-white/[0.06]">
              Falta {formatCurrency(storeKpis.falta)} ÷ {storeKpis.diasRestantes} dias
            </p>
          </div>

          {/* Equipe */}
          <div className="p-4 rounded-xl bg-black/50 border border-white/[0.08]">
            <span className="text-xs text-[#8A8A8A] uppercase font-semibold block mb-1">
              Para a Equipe Bater R$ 155.000
            </span>
            <span className="text-2xl lg:text-3xl font-black text-[#35C759] block">
              {teamKpis.falta > 0 ? `${formatCurrency(teamKpis.ritmoNecessario)}/dia` : 'Meta Conquistada! 🎉'}
            </span>
            <p className="text-xs text-[#8A8A8A] mt-2 pt-2 border-t border-white/[0.06]">
              Falta {formatCurrency(teamKpis.falta)} ÷ {storeKpis.diasRestantes} dias
            </p>
          </div>

          {/* Cada Vendedor */}
          <div className="p-4 rounded-xl bg-black/50 border border-white/[0.08]">
            <span className="text-xs text-[#8A8A8A] uppercase font-semibold block mb-1">
              Média por Vendedor (1/3)
            </span>
            <span className="text-2xl lg:text-3xl font-black text-[#F5C542] block">
              {teamKpis.falta > 0 ? `${formatCurrency(teamKpis.ritmoNecessario / 3)}/dia` : 'Bônus Garantido! 🎉'}
            </span>
            <p className="text-xs text-[#8A8A8A] mt-2 pt-2 border-t border-white/[0.06]">
              Alessandra, Felipe e Arnaldo
            </p>
          </div>
        </div>
      </div>

      {/* Section 20: Quebra Semanal */}
      <WeeklyBreakdownCard
        weeks={weekly}
        title={`Quebra Semanal da ${activeTab === 'loja' ? 'Loja' : 'Equipe'}`}
        type={activeTab}
      />

      {/* Section 19: Quebra da Meta por Dia (Tabela Diária Completa) */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h4 className="text-base font-bold text-white tracking-tight">
              Acompanhamento Diário Detalhado ({activeTab === 'loja' ? 'Loja R$ 400k' : 'Equipe R$ 155k'})
            </h4>
            <p className="text-xs text-[#8A8A8A]">
              Meta Diária, Meta Acumulada, Realizado, Gap e % de Atingimento dia a dia
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/[0.08] text-[#8A8A8A] font-semibold uppercase tracking-wider bg-white/[0.01]">
                <th className="py-3 px-3">Dia</th>
                <th className="py-3 px-3">Meta Diária</th>
                <th className="py-3 px-3">Meta Acumulada</th>
                <th className="py-3 px-3">Realizado no Dia</th>
                <th className="py-3 px-3">Realizado Acumulado</th>
                <th className="py-3 px-3">Gap Acumulado</th>
                <th className="py-3 px-3">% Atingimento</th>
                <th className="py-3 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {dailyPace.map((item) => {
                const percentAtingido =
                  item.realizadoAcumulado !== null && item.metaAcumulada > 0
                    ? (item.realizadoAcumulado / item.metaAcumulada) * 100
                    : null;

                return (
                  <tr
                    key={item.dia}
                    className={clsx(
                      'hover:bg-white/[0.02] transition-colors',
                      item.isFuture && 'opacity-40'
                    )}
                  >
                    <td className="py-3 px-3 font-bold text-white font-mono">
                      {item.dia}
                    </td>
                    <td className="py-3 px-3 text-[#8A8A8A]">
                      {formatCurrency(item.metaDiaria)}
                    </td>
                    <td className="py-3 px-3 text-white/80">
                      {formatCurrency(item.metaAcumulada)}
                    </td>
                    <td className="py-3 px-3 font-semibold text-white">
                      {item.realizadoDia !== null ? formatCurrency(item.realizadoDia) : '--'}
                    </td>
                    <td className="py-3 px-3 font-extrabold text-white">
                      {item.realizadoAcumulado !== null ? formatCurrency(item.realizadoAcumulado) : '--'}
                    </td>
                    <td className="py-3 px-3 font-mono font-bold">
                      {item.gap !== null ? (
                        <span className={item.gap >= 0 ? 'text-[#35C759]' : 'text-[#FF453A]'}>
                          {item.gap >= 0 ? '+' : ''}{formatCurrency(item.gap)}
                        </span>
                      ) : (
                        '--'
                      )}
                    </td>
                    <td className="py-3 px-3 font-bold">
                      {percentAtingido !== null ? (
                        <span className={percentAtingido >= 100 ? 'text-[#35C759]' : percentAtingido >= 85 ? 'text-[#F5C542]' : 'text-[#FF453A]'}>
                          {formatPercent(percentAtingido)}
                        </span>
                      ) : (
                        '--'
                      )}
                    </td>
                    <td className="py-3 px-3">
                      {!item.isFuture ? (
                        <span
                          className={clsx(
                            'text-[10px] font-bold px-2 py-0.5 rounded-full border',
                            item.gap !== null && item.gap >= 0
                              ? 'bg-[#35C759]/15 text-[#35C759] border-[#35C759]/30'
                              : 'bg-[#FF453A]/15 text-[#FF453A] border-[#FF453A]/30'
                          )}
                        >
                          {item.gap !== null && item.gap >= 0 ? 'SUPERANDO' : 'ABAIXO'}
                        </span>
                      ) : (
                        <span className="text-[10px] text-[#8A8A8A]">Previsto</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
