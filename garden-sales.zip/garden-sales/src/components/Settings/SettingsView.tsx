import React, { useState } from 'react';
import { SystemConfig, Seller } from '../../types';
import { formatCurrency, formatPercent } from '../../utils/formatters';
import { clsx } from 'clsx';
import {
  Settings,
  Store,
  Users,
  Trophy,
  Calendar,
  Save,
  RotateCcw,
  Trash2,
  Plus,
  CheckCircle2,
  Sparkles,
  FileSpreadsheet,
  AlertTriangle,
  UserPlus,
} from 'lucide-react';
import { dataService } from '../../services/dataService';

interface SettingsViewProps {
  config: SystemConfig;
  sellers: Seller[];
  onSaveConfig: (config: SystemConfig) => void;
  onSaveSellers: (sellers: Seller[]) => void;
  onResetDemo: () => void;
  onClearEntries: () => void;
  onOpenSheetsModal: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  config,
  sellers,
  onSaveConfig,
  onSaveSellers,
  onResetDemo,
  onClearEntries,
  onOpenSheetsModal,
}) => {
  // Local form state
  const [formData, setFormData] = useState<SystemConfig>({ ...config });
  const [sellersList, setSellersList] = useState<Seller[]>([...sellers]);
  const [newSellerName, setNewSellerName] = useState('');
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [confirmClearOpen, setConfirmClearOpen] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveConfig(formData);
    onSaveSellers(sellersList);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleAddSeller = () => {
    if (!newSellerName.trim()) return;
    const newSeller: Seller = {
      id: `seller-${Date.now()}`,
      nome: newSellerName.trim(),
      ativo: true,
      cor: '#35C759',
    };
    const updated = [...sellersList, newSeller];
    setSellersList(updated);
    setNewSellerName('');
  };

  const toggleSellerActive = (id: string) => {
    const updated = sellersList.map((s) =>
      s.id === id ? { ...s, ativo: !s.ativo } : s
    );
    setSellersList(updated);
  };

  const removeSeller = (id: string) => {
    const updated = sellersList.filter((s) => s.id !== id);
    setSellersList(updated);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold text-white tracking-tight">
            Configurações Administrativas
          </h3>
          <p className="text-xs text-[#8A8A8A] mt-1">
            Personalize metas da loja, média histórica, bonificação da equipe, sistema de pontos e calendário
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenSheetsModal}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-white border border-white/[0.08] text-xs font-semibold transition-all"
          >
            <FileSpreadsheet className="w-4 h-4 text-[#35C759]" />
            <span>Google Sheets</span>
          </button>
        </div>
      </div>

      {saveSuccess && (
        <div className="p-4 rounded-xl bg-[#35C759]/15 border border-[#35C759]/30 text-[#35C759] flex items-center gap-2 text-sm font-semibold animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 shrink-0" />
          <span>Configurações salvas e todos os cálculos recalculados com sucesso!</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Bloco 1: Loja e Remuneração da Gestão (#3 & #39) */}
        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6">
          <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-white/[0.08]">
            <Store className="w-5 h-5 text-[#35C759]" />
            <div>
              <h4 className="text-base font-bold text-white tracking-tight">
                Parâmetros Comerciais da Loja (Garden Center)
              </h4>
              <p className="text-xs text-[#8A8A8A]">
                Regra da Seção 3: O gestor Guilherme recebe percentual sobre o excedente da média histórica
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1.5">
                Média Histórica da Loja (R$)
              </label>
              <input
                type="number"
                step="1000"
                required
                value={formData.mediaHistoricaLoja}
                onChange={(e) =>
                  setFormData({ ...formData, mediaHistoricaLoja: parseFloat(e.target.value) || 0 })
                }
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
              />
              <span className="text-[11px] text-[#8A8A8A] mt-1 block">
                Valor padrão do projeto: R$ 354.000,00
              </span>
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1.5">
                Meta Mensal da Loja (R$)
              </label>
              <input
                type="number"
                step="1000"
                required
                value={formData.metaLoja}
                onChange={(e) =>
                  setFormData({ ...formData, metaLoja: parseFloat(e.target.value) || 0 })
                }
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
              />
              <span className="text-[11px] text-[#8A8A8A] mt-1 block">
                Valor padrão do projeto: R$ 400.000,00
              </span>
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1.5">
                % Remuneração do Gestor (%)
              </label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="100"
                required
                value={formData.percentualRemuneracaoLoja}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    percentualRemuneracaoLoja: parseFloat(e.target.value) || 0,
                  })
                }
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
              />
              <span className="text-[11px] text-[#8A8A8A] mt-1 block">
                Padrão: 2,0% sobre o excedente
              </span>
            </div>
          </div>
        </div>

        {/* Bloco 2: Equipe de Vendas e Bônus Coletivo (#4, #5 & #39) */}
        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6">
          <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-white/[0.08]">
            <Users className="w-5 h-5 text-blue-400" />
            <div>
              <h4 className="text-base font-bold text-white tracking-tight">
                Metas e Bonificação da Equipe de Vendas
              </h4>
              <p className="text-xs text-[#8A8A8A]">
                Regra das Seções 4 e 5: Meta coletiva de R$ 155.000 com bônus de R$ 200 por vendedor
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1.5">
                Média Histórica da Equipe (R$)
              </label>
              <input
                type="number"
                step="1000"
                required
                value={formData.mediaHistoricaEquipe}
                onChange={(e) =>
                  setFormData({ ...formData, mediaHistoricaEquipe: parseFloat(e.target.value) || 0 })
                }
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
              />
              <span className="text-[11px] text-[#8A8A8A] mt-1 block">
                Padrão: R$ 140.000,00
              </span>
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1.5">
                Meta Coletiva da Equipe (R$)
              </label>
              <input
                type="number"
                step="1000"
                required
                value={formData.metaEquipe}
                onChange={(e) =>
                  setFormData({ ...formData, metaEquipe: parseFloat(e.target.value) || 0 })
                }
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
              />
              <span className="text-[11px] text-[#8A8A8A] mt-1 block">
                Padrão: R$ 155.000,00
              </span>
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1.5">
                Bônus por Vendedor (R$)
              </label>
              <input
                type="number"
                step="10"
                required
                value={formData.bonusPorVendedor}
                onChange={(e) =>
                  setFormData({ ...formData, bonusPorVendedor: parseFloat(e.target.value) || 0 })
                }
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
              />
              <span className="text-[11px] text-[#8A8A8A] mt-1 block">
                Padrão: R$ 200,00 (Total R$ 600 coletivo)
              </span>
            </div>
          </div>
        </div>

        {/* Bloco 3: Sistema de Pontos da Equipe (#6 & #39) */}
        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6">
          <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-white/[0.08]">
            <Trophy className="w-5 h-5 text-amber-400" />
            <div>
              <h4 className="text-base font-bold text-white tracking-tight">
                Regras do Sistema de Pontos da Equipe
              </h4>
              <p className="text-xs text-[#8A8A8A]">
                Regra da Seção 6: Acima da meta, a cada 10% de aumento = +100 pontos (≈ R$ 100)
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1.5">
                % de Aumento por Nível (%)
              </label>
              <input
                type="number"
                step="1"
                min="1"
                max="50"
                required
                value={formData.percentualIncrementoPontos}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    percentualIncrementoPontos: parseFloat(e.target.value) || 0,
                  })
                }
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
              />
              <span className="text-[11px] text-[#8A8A8A] mt-1 block">
                Padrão: 10% sobre a meta
              </span>
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1.5">
                Pontos Concedidos por Nível
              </label>
              <input
                type="number"
                step="10"
                required
                value={formData.pontosPorIncremento}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    pontosPorIncremento: parseInt(e.target.value, 10) || 0,
                  })
                }
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
              />
              <span className="text-[11px] text-[#8A8A8A] mt-1 block">
                Padrão: 100 pontos
              </span>
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1.5">
                Valor Financeiro por Ponto (R$)
              </label>
              <input
                type="number"
                step="0.1"
                required
                value={formData.valorPorPonto}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    valorPorPonto: parseFloat(e.target.value) || 0,
                  })
                }
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
              />
              <span className="text-[11px] text-[#8A8A8A] mt-1 block">
                Padrão: R$ 1,00 (100 pontos ≈ R$ 100,00)
              </span>
            </div>
          </div>
        </div>

        {/* Bloco 4: Calendário Operacional (#39) */}
        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6">
          <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-white/[0.08]">
            <Calendar className="w-5 h-5 text-purple-400" />
            <div>
              <h4 className="text-base font-bold text-white tracking-tight">
                Calendário e Dias Operacionais
              </h4>
              <p className="text-xs text-[#8A8A8A]">
                Define a base de cálculo para metas diárias, projeções e ritmo de vendas
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1.5">
                Nome do Mês de Referência
              </label>
              <input
                type="text"
                required
                value={formData.nomeMesReferencia}
                onChange={(e) =>
                  setFormData({ ...formData, nomeMesReferencia: e.target.value })
                }
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-[#35C759]"
              />
              <span className="text-[11px] text-[#8A8A8A] mt-1 block">
                Ex: Setembro 2026 / Outubro 2026
              </span>
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1.5">
                Dias Operacionais no Mês
              </label>
              <input
                type="number"
                min="1"
                max="31"
                required
                value={formData.diasOperacionais}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    diasOperacionais: parseInt(e.target.value, 10) || 26,
                  })
                }
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
              />
              <span className="text-[11px] text-[#8A8A8A] mt-1 block">
                Total de dias com loja aberta no mês
              </span>
            </div>

            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1.5">
                Dias Decorridos até Hoje
              </label>
              <input
                type="number"
                min="1"
                max="31"
                required
                value={formData.diasDecorridos}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    diasDecorridos: parseInt(e.target.value, 10) || 24,
                  })
                }
                className="w-full px-3.5 py-2.5 bg-black/60 border border-white/10 rounded-xl text-sm text-white font-mono focus:outline-none focus:border-[#35C759]"
              />
              <span className="text-[11px] text-[#8A8A8A] mt-1 block">
                Hoje no sistema: Dia 24/09/2026
              </span>
            </div>
          </div>
        </div>

        {/* Bloco 5: Gestão de Vendedores (#50: Preparado para crescimento) */}
        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6">
          <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-white/[0.08]">
            <UserPlus className="w-5 h-5 text-emerald-400" />
            <div>
              <h4 className="text-base font-bold text-white tracking-tight">
                Gestão da Equipe Comercial
              </h4>
              <p className="text-xs text-[#8A8A8A]">
                Permite adicionar novos vendedores futuramente sem alterar código (#50)
              </p>
            </div>
          </div>

          <div className="flex gap-2 mb-4">
            <input
              type="text"
              placeholder="Nome do novo vendedor..."
              value={newSellerName}
              onChange={(e) => setNewSellerName(e.target.value)}
              className="flex-1 px-3.5 py-2 bg-black/60 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-[#35C759]"
            />
            <button
              type="button"
              onClick={handleAddSeller}
              className="px-4 py-2 bg-white/[0.08] hover:bg-white/[0.15] text-white text-xs font-semibold rounded-xl border border-white/10 transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5 text-[#35C759]" />
              <span>Adicionar Vendedor</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {sellersList.map((s) => (
              <div
                key={s.id}
                className="p-3 rounded-xl bg-black/40 border border-white/[0.06] flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <span
                    className={clsx(
                      'w-2 h-2 rounded-full',
                      s.ativo ? 'bg-[#35C759]' : 'bg-[#8A8A8A]'
                    )}
                  />
                  <span className={clsx('text-xs font-bold', s.ativo ? 'text-white' : 'text-[#8A8A8A] line-through')}>
                    {s.nome}
                  </span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => toggleSellerActive(s.id)}
                    className="text-[10px] px-2 py-0.5 rounded bg-white/[0.04] text-[#8A8A8A] hover:text-white"
                  >
                    {s.ativo ? 'Ativo' : 'Inativo'}
                  </button>
                  {sellersList.length > 3 && (
                    <button
                      type="button"
                      onClick={() => removeSeller(s.id)}
                      className="p-1 text-[#8A8A8A] hover:text-[#FF453A]"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Actions Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-white/[0.08]">
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={onResetDemo}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-[#8A8A8A] hover:text-white text-xs font-semibold border border-white/[0.08] transition-colors"
              title="Restaurar lançamentos e configurações de demonstração"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Restaurar Dados Demo</span>
            </button>

            <button
              type="button"
              onClick={() => setConfirmClearOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#FF453A]/10 hover:bg-[#FF453A]/20 text-[#FF453A] text-xs font-semibold border border-[#FF453A]/20 transition-colors"
              title="Limpar todos os lançamentos para iniciar operação do zero"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Limpar Lançamentos</span>
            </button>
          </div>

          <button
            type="submit"
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-[#35C759] hover:bg-[#2db34e] text-black text-xs font-bold transition-all shadow-[0_0_20px_rgba(53,199,89,0.3)]"
          >
            <Save className="w-4 h-4 text-black" />
            <span>SALVAR CONFIGURAÇÕES</span>
          </button>
        </div>
      </form>

      {/* Confirmation Modal to Clear Data */}
      {confirmClearOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setConfirmClearOpen(false)} />
          <div className="relative w-full max-w-md rounded-2xl border border-white/10 bg-[#101010] p-6 text-white z-10 space-y-4">
            <h4 className="text-base font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-[#FF453A]" />
              Limpar Todos os Lançamentos?
            </h4>
            <p className="text-xs text-[#8A8A8A]">
              Isso removerá todas as vendas registradas para que você possa iniciar lançamentos reais do zero.
              As configurações e a equipe de vendedores serão preservadas.
            </p>
            <div className="flex items-center justify-end gap-2 pt-3 border-t border-white/[0.08]">
              <button
                type="button"
                onClick={() => setConfirmClearOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-[#8A8A8A] hover:text-white"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  onClearEntries();
                  setConfirmClearOpen(false);
                }}
                className="px-4 py-2 rounded-xl bg-[#FF453A] hover:bg-red-600 text-white text-xs font-bold transition-colors"
              >
                Sim, Limpar Tudo
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
