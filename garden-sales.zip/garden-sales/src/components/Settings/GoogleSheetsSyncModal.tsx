import React, { useState } from 'react';
import { Modal } from '../Common/Modal';
import { SystemConfig } from '../../types';
import { dataService } from '../../services/dataService';
import { clsx } from 'clsx';
import {
  FileSpreadsheet,
  Link2,
  Download,
  Upload,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  ExternalLink,
  Copy,
  Check,
} from 'lucide-react';

interface GoogleSheetsSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: SystemConfig;
  onConfigChange: (newConfig: SystemConfig) => void;
  onRefreshData: () => void;
}

export const GoogleSheetsSyncModal: React.FC<GoogleSheetsSyncModalProps> = ({
  isOpen,
  onClose,
  config,
  onConfigChange,
  onRefreshData,
}) => {
  const [sheetUrl, setSheetUrl] = useState(config.googleSheetsUrl || '');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState<{ type: 'idle' | 'success' | 'error'; message: string }>({
    type: 'idle',
    message: '',
  });
  const [importCsvText, setImportCsvText] = useState('');
  const [copiedScript, setCopiedScript] = useState(false);

  const handleTestSync = async () => {
    setIsSyncing(true);
    setSyncStatus({ type: 'idle', message: 'Conectando ao Google Sheets...' });

    const result = await dataService.syncGoogleSheets(sheetUrl);
    setIsSyncing(false);

    if (result.success) {
      setSyncStatus({ type: 'success', message: result.message });
      const updatedConfig = {
        ...config,
        googleSheetsUrl: sheetUrl,
        googleSheetsConnected: true,
        ultimaSincronizacao: dataService.getLastSyncTime(),
      };
      onConfigChange(updatedConfig);
      dataService.saveConfig(updatedConfig);
      onRefreshData();
    } else {
      setSyncStatus({ type: 'error', message: result.message });
    }
  };

  const handleManualImport = () => {
    if (!importCsvText.trim()) return;
    const res = dataService.importSalesFromCsv(importCsvText);
    if (res.success) {
      setSyncStatus({
        type: 'success',
        message: `Importação realizada com sucesso! ${res.count} lançamentos adicionados.`,
      });
      setImportCsvText('');
      onRefreshData();
    } else {
      setSyncStatus({ type: 'error', message: res.error || 'Erro na importação' });
    }
  };

  const handleExportSales = () => {
    const csv = dataService.exportSalesCsv();
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `DADOS_VENDAS_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportConfig = () => {
    const csv = dataService.exportConfigCsv();
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `CONFIG_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const sampleAppsScript = `// Google Apps Script (Extensões > Apps Script na sua planilha)
function doGet(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("DADOS_VENDAS");
  var data = sheet.getDataRange().getValues();
  var csv = data.map(function(row) { return row.join(","); }).join("\\n");
  return ContentService.createTextOutput(csv).setMimeType(ContentService.MimeType.CSV);
}`;

  const copyScriptToClipboard = () => {
    navigator.clipboard.writeText(sampleAppsScript);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2000);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Integração com Google Sheets"
      subtitle="Conexão com a base de dados operacional conforme especificações das Seções 36 e 37."
      maxWidth="2xl"
    >
      <div className="space-y-6">
        {/* Status Card */}
        <div className="p-4 rounded-xl bg-black/40 border border-white/[0.08] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Google Sheets Hub</h4>
              <p className="text-xs text-[#8A8A8A]">
                Abas: <span className="font-mono text-white">DADOS_VENDAS</span> e <span className="font-mono text-white">CONFIG</span>
              </p>
            </div>
          </div>

          <span
            className={clsx(
              'px-2.5 py-1 rounded-full text-xs font-bold border uppercase',
              config.googleSheetsConnected
                ? 'bg-[#35C759]/20 text-[#35C759] border-[#35C759]/30'
                : 'bg-white/[0.06] text-[#8A8A8A] border-white/10'
            )}
          >
            {config.googleSheetsConnected ? 'CONECTADO' : 'LOCAL / PRONTO'}
          </span>
        </div>

        {/* Sync URL Configuration */}
        <div className="space-y-2">
          <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block">
            URL da Planilha Publicada (CSV) ou Web App Apps Script:
          </label>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Link2 className="w-4 h-4 text-[#8A8A8A] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="url"
                placeholder="https://docs.google.com/spreadsheets/d/.../pub?output=csv"
                value={sheetUrl}
                onChange={(e) => setSheetUrl(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 bg-black/60 border border-white/10 rounded-xl text-xs text-white placeholder-[#8A8A8A] focus:outline-none focus:border-[#35C759]"
              />
            </div>

            <button
              onClick={handleTestSync}
              disabled={isSyncing}
              className="px-4 py-2 rounded-xl bg-[#35C759] hover:bg-[#2db34e] text-black text-xs font-bold transition-all disabled:opacity-50 shrink-0 flex items-center gap-1.5"
            >
              <RefreshCw className={clsx('w-3.5 h-3.5', isSyncing && 'animate-spin')} />
              <span>Sincronizar</span>
            </button>
          </div>

          {syncStatus.message && (
            <div
              className={clsx(
                'p-3 rounded-xl border text-xs flex items-center gap-2 mt-2',
                syncStatus.type === 'success'
                  ? 'bg-[#35C759]/10 border-[#35C759]/30 text-[#35C759]'
                  : 'bg-[#FF453A]/10 border-[#FF453A]/30 text-[#FF453A]'
              )}
            >
              {syncStatus.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0" />
              ) : (
                <AlertTriangle className="w-4 h-4 shrink-0" />
              )}
              <span>{syncStatus.message}</span>
            </div>
          )}
        </div>

        {/* Exportar Modelos de CSV Compatíveis */}
        <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.06] space-y-3">
          <h5 className="text-xs font-bold text-white uppercase tracking-wider">
            Exportar Modelos no Formato Google Sheets (Seção 36)
          </h5>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={handleExportSales}
              className="flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-black/40 hover:bg-black/60 border border-white/[0.08] text-xs font-semibold text-white transition-all"
            >
              <Download className="w-4 h-4 text-[#35C759]" />
              <span>Baixar DADOS_VENDAS.csv</span>
            </button>
            <button
              onClick={handleExportConfig}
              className="flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-black/40 hover:bg-black/60 border border-white/[0.08] text-xs font-semibold text-white transition-all"
            >
              <Download className="w-4 h-4 text-[#F5C542]" />
              <span>Baixar CONFIG.csv</span>
            </button>
          </div>
        </div>

        {/* Importação Rápida via Colar Texto */}
        <div className="space-y-2">
          <label className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block">
            Importação Direta (Copie da planilha e cole aqui):
          </label>
          <textarea
            rows={3}
            placeholder="DATA,VENDEDOR,FATURAMENTO,NUM_VENDAS,TICKET_MEDIO&#10;2026-09-24,Arnaldo,12568.30,100,125.68"
            value={importCsvText}
            onChange={(e) => setImportCsvText(e.target.value)}
            className="w-full p-3 bg-black/60 border border-white/10 rounded-xl text-xs text-white font-mono placeholder-[#8A8A8A] focus:outline-none focus:border-[#35C759]"
          />
          <button
            onClick={handleManualImport}
            disabled={!importCsvText.trim()}
            className="px-4 py-2 rounded-xl bg-white/[0.08] hover:bg-white/[0.15] text-white text-xs font-semibold transition-all border border-white/10 disabled:opacity-40 flex items-center gap-1.5"
          >
            <Upload className="w-3.5 h-3.5 text-[#35C759]" />
            <span>Processar e Importar Lançamentos</span>
          </button>
        </div>

        {/* Como Configurar o Google Sheets */}
        <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06] space-y-2 text-xs text-[#8A8A8A]">
          <div className="flex items-center justify-between">
            <span className="font-bold text-white uppercase text-[11px]">
              Instruções de Conexão Rápida:
            </span>
            <button
              onClick={copyScriptToClipboard}
              className="text-[10px] text-[#35C759] hover:underline flex items-center gap-1"
            >
              {copiedScript ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              {copiedScript ? 'Copiado!' : 'Copiar Script'}
            </button>
          </div>
          <ol className="list-decimal list-inside space-y-1 leading-relaxed">
            <li>Crie uma planilha no Google Sheets com as abas <strong className="text-white">DADOS_VENDAS</strong> e <strong className="text-white">CONFIG</strong>.</li>
            <li>No Google Sheets, clique em <strong className="text-white">Arquivo &gt; Compartilhar &gt; Publicar na Web</strong>.</li>
            <li>Selecione a aba <strong className="text-white">DADOS_VENDAS</strong> no formato <strong className="text-white">CSV</strong>.</li>
            <li>Copie o link gerado e cole no campo acima para sincronização automática.</li>
          </ol>
        </div>
      </div>
    </Modal>
  );
};
