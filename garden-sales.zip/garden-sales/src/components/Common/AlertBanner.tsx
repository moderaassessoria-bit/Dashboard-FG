import React from 'react';
import { clsx } from 'clsx';
import { CheckCircle2, AlertTriangle, AlertCircle, X } from 'lucide-react';
import { SmartAlert } from '../../types';

interface AlertBannerProps {
  alert: SmartAlert;
  onDismiss?: (id: string) => void;
}

export const AlertBanner: React.FC<AlertBannerProps> = ({ alert, onDismiss }) => {
  const getIcon = () => {
    switch (alert.tipo) {
      case 'positivo':
        return <CheckCircle2 className="w-5 h-5 text-[#35C759] shrink-0" />;
      case 'alerta':
        return <AlertTriangle className="w-5 h-5 text-[#F5C542] shrink-0" />;
      case 'negativo':
      default:
        return <AlertCircle className="w-5 h-5 text-[#FF453A] shrink-0" />;
    }
  };

  const getContainerStyles = () => {
    switch (alert.tipo) {
      case 'positivo':
        return 'bg-[#35C759]/5 border-[#35C759]/20 text-[#35C759]';
      case 'alerta':
        return 'bg-[#F5C542]/5 border-[#F5C542]/20 text-[#F5C542]';
      case 'negativo':
      default:
        return 'bg-[#FF453A]/5 border-[#FF453A]/20 text-[#FF453A]';
    }
  };

  return (
    <div
      className={clsx(
        'relative flex items-start gap-3 p-3.5 rounded-xl border backdrop-blur-md transition-all',
        getContainerStyles()
      )}
    >
      <div className="mt-0.5">{getIcon()}</div>
      <div className="flex-1 pr-6">
        <h4 className="text-xs font-semibold uppercase tracking-wider mb-0.5">
          {alert.titulo}
        </h4>
        <p className="text-sm font-normal text-white/90 leading-snug">
          {alert.mensagem}
        </p>
      </div>

      {onDismiss && (
        <button
          onClick={() => onDismiss(alert.id)}
          className="absolute top-3 right-3 text-white/40 hover:text-white transition-colors p-1"
          title="Fechar alerta"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
};
