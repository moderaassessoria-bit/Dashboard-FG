import React from 'react';
import { clsx } from 'clsx';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string;
  subtitle?: string;
  secondaryValue?: string;
  icon?: LucideIcon;
  trend?: {
    direction: 'up' | 'down' | 'neutral';
    text: string;
  };
  status?: 'positivo' | 'alerta' | 'negativo' | 'neutro';
  highlight?: boolean;
  className?: string;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  secondaryValue,
  icon: Icon,
  trend,
  status = 'neutro',
  highlight = false,
  className,
}) => {
  const getStatusBorder = () => {
    switch (status) {
      case 'positivo':
        return 'border-[#35C759]/30 hover:border-[#35C759]/60 shadow-[0_0_20px_rgba(53,199,89,0.08)]';
      case 'alerta':
        return 'border-[#F5C542]/30 hover:border-[#F5C542]/60 shadow-[0_0_20px_rgba(245,197,66,0.08)]';
      case 'negativo':
        return 'border-[#FF453A]/30 hover:border-[#FF453A]/60 shadow-[0_0_20px_rgba(255,69,58,0.08)]';
      default:
        return 'border-white/[0.08] hover:border-white/20';
    }
  };

  const getValueColor = () => {
    switch (status) {
      case 'positivo':
        return 'text-[#35C759]';
      case 'alerta':
        return 'text-[#F5C542]';
      case 'negativo':
        return 'text-[#FF453A]';
      default:
        return 'text-white';
    }
  };

  return (
    <div
      className={clsx(
        'relative overflow-hidden rounded-xl border bg-white/[0.03] backdrop-blur-md p-5 transition-all duration-300 hover:translate-y-[-2px] group',
        getStatusBorder(),
        highlight && 'bg-gradient-to-br from-white/[0.06] to-white/[0.02]',
        className
      )}
    >
      {/* Background glow for highlight */}
      {highlight && (
        <div className="absolute -top-12 -right-12 w-32 h-32 bg-[#35C759]/10 rounded-full blur-2xl pointer-events-none" />
      )}

      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-semibold tracking-wider text-[#8A8A8A] uppercase">
          {title}
        </span>
        {Icon && (
          <div className="p-2 rounded-lg bg-white/[0.04] text-[#8A8A8A] group-hover:text-white transition-colors">
            <Icon className="w-4 h-4" />
          </div>
        )}
      </div>

      <div className="flex items-baseline gap-2 mb-1">
        <div className={clsx('text-2xl lg:text-3xl font-bold tracking-tight', getValueColor())}>
          {value}
        </div>
        {secondaryValue && (
          <span className="text-xs font-medium text-[#8A8A8A]">
            {secondaryValue}
          </span>
        )}
      </div>

      {(subtitle || trend) && (
        <div className="flex items-center justify-between text-xs mt-2 pt-2 border-t border-white/[0.04]">
          {subtitle && <span className="text-[#8A8A8A] truncate">{subtitle}</span>}
          {trend && (
            <span
              className={clsx(
                'font-medium ml-auto flex items-center gap-1',
                trend.direction === 'up' && 'text-[#35C759]',
                trend.direction === 'down' && 'text-[#FF453A]',
                trend.direction === 'neutral' && 'text-[#F5C542]'
              )}
            >
              {trend.text}
            </span>
          )}
        </div>
      )}
    </div>
  );
};
