import React from 'react';
import { clsx } from 'clsx';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'positivo' | 'alerta' | 'negativo' | 'neutro' | 'info' | 'purple';
  size?: 'sm' | 'md';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'neutro',
  size = 'md',
  className,
}) => {
  const getColors = () => {
    switch (variant) {
      case 'positivo':
        return 'bg-[#35C759]/15 text-[#35C759] border-[#35C759]/30';
      case 'alerta':
        return 'bg-[#F5C542]/15 text-[#F5C542] border-[#F5C542]/30';
      case 'negativo':
        return 'bg-[#FF453A]/15 text-[#FF453A] border-[#FF453A]/30';
      case 'info':
        return 'bg-blue-500/15 text-blue-400 border-blue-500/30';
      case 'purple':
        return 'bg-purple-500/15 text-purple-400 border-purple-500/30';
      case 'neutro':
      default:
        return 'bg-white/[0.06] text-[#8A8A8A] border-white/10';
    }
  };

  return (
    <span
      className={clsx(
        'inline-flex items-center gap-1.5 font-medium border rounded-full uppercase tracking-wider',
        size === 'sm' ? 'px-2 py-0.5 text-[10px]' : 'px-2.5 py-1 text-xs',
        getColors(),
        className
      )}
    >
      <span
        className={clsx(
          'w-1.5 h-1.5 rounded-full',
          variant === 'positivo' && 'bg-[#35C759]',
          variant === 'alerta' && 'bg-[#F5C542]',
          variant === 'negativo' && 'bg-[#FF453A]',
          variant === 'info' && 'bg-blue-400',
          variant === 'purple' && 'bg-purple-400',
          variant === 'neutro' && 'bg-[#8A8A8A]'
        )}
      />
      {children}
    </span>
  );
};
