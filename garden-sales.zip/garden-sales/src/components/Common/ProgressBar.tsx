import React from 'react';
import { clsx } from 'clsx';
import { formatPercent } from '../../utils/formatters';

interface ProgressBarProps {
  current: number;
  target: number;
  label?: string;
  sublabel?: string;
  showPercent?: boolean;
  statusOverride?: 'positivo' | 'alerta' | 'negativo';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  current,
  target,
  label,
  sublabel,
  showPercent = true,
  statusOverride,
  size = 'md',
  className,
}) => {
  const percent = target > 0 ? (current / target) * 100 : 0;
  const clampedPercent = Math.min(100, Math.max(0, percent));

  const getStatus = (): 'positivo' | 'alerta' | 'negativo' => {
    if (statusOverride) return statusOverride;
    if (percent >= 100) return 'positivo';
    if (percent >= 85) return 'alerta';
    return 'negativo';
  };

  const status = getStatus();

  const getBarColor = () => {
    switch (status) {
      case 'positivo':
        return 'bg-gradient-to-r from-[#1F8F4C] to-[#35C759] shadow-[0_0_12px_rgba(53,199,89,0.4)]';
      case 'alerta':
        return 'bg-gradient-to-r from-[#D97706] to-[#F5C542] shadow-[0_0_12px_rgba(245,197,66,0.4)]';
      case 'negativo':
      default:
        return 'bg-gradient-to-r from-[#B91C1C] to-[#FF453A] shadow-[0_0_12px_rgba(255,69,58,0.4)]';
    }
  };

  const getHeight = () => {
    switch (size) {
      case 'sm':
        return 'h-1.5';
      case 'lg':
        return 'h-4';
      case 'xl':
        return 'h-6';
      case 'md':
      default:
        return 'h-2.5';
    }
  };

  return (
    <div className={clsx('w-full', className)}>
      {(label || showPercent) && (
        <div className="flex items-center justify-between mb-2 text-xs">
          <div>
            {label && <span className="font-medium text-white">{label}</span>}
            {sublabel && <span className="text-[#8A8A8A] ml-2">({sublabel})</span>}
          </div>
          {showPercent && (
            <span
              className={clsx(
                'font-bold text-sm tracking-tight',
                status === 'positivo' && 'text-[#35C759]',
                status === 'alerta' && 'text-[#F5C542]',
                status === 'negativo' && 'text-[#FF453A]'
              )}
            >
              {formatPercent(percent)}
            </span>
          )}
        </div>
      )}

      <div className={clsx('w-full bg-white/[0.06] rounded-full overflow-hidden p-0.5 border border-white/[0.04]', getHeight())}>
        <div
          className={clsx('h-full rounded-full transition-all duration-700 ease-out', getBarColor())}
          style={{ width: `${clampedPercent}%` }}
        />
      </div>
    </div>
  );
};
