import React from 'react';
import { WeeklyBreakdown } from '../../types';
import { formatCurrency, formatPercent } from '../../utils/formatters';
import { Badge } from '../Common/Badge';
import { clsx } from 'clsx';
import { CalendarDays, CheckCircle, AlertTriangle, XCircle } from 'lucide-react';

interface WeeklyBreakdownCardProps {
  weeks: WeeklyBreakdown[];
  title?: string;
  type?: 'loja' | 'equipe';
}

export const WeeklyBreakdownCard: React.FC<WeeklyBreakdownCardProps> = ({
  weeks,
  title = 'Quebra Semanal de Desempenho',
  type = 'loja',
}) => {
  const getStatusBadge = (status: 'atingido' | 'atencao' | 'critico') => {
    switch (status) {
      case 'atingido':
        return <Badge variant="positivo" size="sm">ATINGIDO</Badge>;
      case 'atencao':
        return <Badge variant="alerta" size="sm">ATENÇÃO</Badge>;
      case 'critico':
      default:
        return <Badge variant="negativo" size="sm">CRÍTICO</Badge>;
    }
  };

  return (
    <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-5 lg:p-6 transition-all">
      <div className="flex items-center justify-between mb-5">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-white/[0.04] text-[#35C759]">
            <CalendarDays className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white tracking-tight">
              {title}
            </h3>
            <p className="text-xs text-[#8A8A8A]">
              Evolução e metas distribuídas pelas semanas operacionais
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
        {weeks.map((week) => {
          const falta = Math.max(0, week.meta - week.realizado);
          const isFinishedOrCurrent = week.realizado > 0;

          return (
            <div
              key={week.semana}
              className={clsx(
                'relative p-4 rounded-xl border bg-black/40 transition-all hover:border-white/20 flex flex-col justify-between',
                week.status === 'atingido' && isFinishedOrCurrent && 'border-[#35C759]/30 bg-[#35C759]/[0.02]',
                week.status === 'atencao' && isFinishedOrCurrent && 'border-[#F5C542]/30 bg-[#F5C542]/[0.02]',
                week.status === 'critico' && isFinishedOrCurrent && 'border-[#FF453A]/30 bg-[#FF453A]/[0.02]',
                !isFinishedOrCurrent && 'border-white/[0.05] opacity-60'
              )}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    {week.label}
                  </span>
                  {getStatusBadge(week.status)}
                </div>

                <p className="text-[11px] text-[#8A8A8A] mb-3">
                  {week.diasPeriodo}
                </p>

                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-[#8A8A8A]">Meta:</span>
                    <span className="font-semibold text-white/90">
                      {formatCurrency(week.meta)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-[#8A8A8A]">Realizado:</span>
                    <span className="font-bold text-white">
                      {formatCurrency(week.realizado)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center pt-1 border-t border-white/[0.06]">
                    <span className="text-[#8A8A8A]">Atingimento:</span>
                    <span
                      className={clsx(
                        'font-bold',
                        week.atingimentoPercent >= 100
                          ? 'text-[#35C759]'
                          : week.atingimentoPercent >= 85
                          ? 'text-[#F5C542]'
                          : 'text-[#FF453A]'
                      )}
                    >
                      {formatPercent(week.atingimentoPercent)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-[#8A8A8A]">Falta:</span>
                    <span className="font-mono text-white/80">
                      {falta > 0 ? formatCurrency(falta) : 'R$ 0,00'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Mini progress bar on card */}
              <div className="mt-3 pt-2 border-t border-white/[0.04]">
                <div className="w-full bg-white/[0.06] rounded-full h-1.5 overflow-hidden">
                  <div
                    className={clsx(
                      'h-full rounded-full transition-all duration-500',
                      week.status === 'atingido'
                        ? 'bg-[#35C759]'
                        : week.status === 'atencao'
                        ? 'bg-[#F5C542]'
                        : 'bg-[#FF453A]'
                    )}
                    style={{ width: `${Math.min(100, Math.max(0, week.atingimentoPercent))}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
