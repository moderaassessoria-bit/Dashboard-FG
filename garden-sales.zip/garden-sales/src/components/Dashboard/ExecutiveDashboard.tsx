import React from 'react';
import {
  StoreKpis,
  TeamKpis,
  WeeklyBreakdown,
  SmartAlert,
  SystemConfig,
} from '../../types';
import { StatCard } from '../Common/StatCard';
import { TargetGauge } from './TargetGauge';
import { SalesTrendChart } from './SalesTrendChart';
import { WeeklyBreakdownCard } from './WeeklyBreakdownCard';
import { AlertBanner } from '../Common/AlertBanner';
import {
  formatCurrency,
  formatPercent,
  formatNumber,
} from '../../utils/formatters';
import {
  DollarSign,
  Target,
  Activity,
  Flame,
  Receipt,
  ShoppingBag,
  TrendingUp,
  AlertCircle,
  Calendar,
  Layers,
} from 'lucide-react';
import { computeDailyAccumulated } from '../../utils/calculations';
import { SaleEntry } from '../../types';

interface ExecutiveDashboardProps {
  storeKpis: StoreKpis;
  teamKpis: TeamKpis;
  weeklyBreakdown: WeeklyBreakdown[];
  smartAlerts: SmartAlert[];
  entries: SaleEntry[];
  config: SystemConfig;
  onNavigateTo: (page: any) => void;
  onOpenNewEntry: () => void;
}

export const ExecutiveDashboard: React.FC<ExecutiveDashboardProps> = ({
  storeKpis,
  teamKpis,
  weeklyBreakdown,
  smartAlerts,
  entries,
  config,
  onNavigateTo,
  onOpenNewEntry,
}) => {
  const dailyData = computeDailyAccumulated(entries, config, 'loja');

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Smart Alerts Section (#40) */}
      {smartAlerts.length > 0 && (
        <div className="space-y-2">
          {smartAlerts.slice(0, 2).map((alert) => (
            <AlertBanner key={alert.id} alert={alert} />
          ))}
        </div>
      )}

      {/* 7 Principal Cards from Section 16 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. FATURAMENTO */}
        <StatCard
          title="Faturamento"
          value={formatCurrency(storeKpis.realizado)}
          subtitle={`Meta: ${formatCurrency(storeKpis.meta)}`}
          secondaryValue={`(${formatPercent(storeKpis.atingimentoPercent)})`}
          icon={DollarSign}
          status={storeKpis.atingimentoPercent >= 100 ? 'positivo' : storeKpis.atingimentoPercent >= 85 ? 'alerta' : 'negativo'}
          highlight
          trend={{
            direction: storeKpis.atingimentoPercent >= 85 ? 'up' : 'down',
            text: `${formatPercent(storeKpis.atingimentoPercent)} atingido`,
          }}
        />

        {/* 2. FALTA PARA META */}
        <StatCard
          title="Falta Para Meta"
          value={formatCurrency(storeKpis.falta)}
          subtitle={storeKpis.falta === 0 ? 'Meta Alcançada!' : `${storeKpis.diasRestantes} dias operacionais restantes`}
          secondaryValue={`(${formatPercent(storeKpis.faltaPercent)} restante)`}
          icon={Target}
          status={storeKpis.falta === 0 ? 'positivo' : storeKpis.faltaPercent <= 15 ? 'alerta' : 'negativo'}
        />

        {/* 3. RITMO ATUAL */}
        <StatCard
          title="Ritmo Atual"
          value={`${formatCurrency(storeKpis.ritmoAtual)}/dia`}
          subtitle={`Média em ${storeKpis.diasDecorridos} dias decorridos`}
          icon={Activity}
          status={storeKpis.statusRitmo}
          trend={{
            direction: storeKpis.statusRitmo === 'positivo' ? 'up' : 'down',
            text: storeKpis.statusRitmo === 'positivo' ? 'No ritmo ideal' : 'Abaixo do ideal',
          }}
        />

        {/* 4. NECESSÁRIO POR DIA */}
        <StatCard
          title="Necessário Por Dia"
          value={storeKpis.falta > 0 ? `${formatCurrency(storeKpis.ritmoNecessario)}/dia` : 'Meta Concluída!'}
          subtitle={storeKpis.falta > 0 ? `Para bater ${formatCurrency(storeKpis.meta)}` : 'Desafio batido'}
          icon={Flame}
          status={storeKpis.falta === 0 ? 'positivo' : storeKpis.ritmoNecessario <= storeKpis.ritmoAtual ? 'positivo' : 'alerta'}
        />

        {/* 5. TICKET MÉDIO */}
        <StatCard
          title="Ticket Médio"
          value={formatCurrency(storeKpis.ticketMedio)}
          subtitle={`Calculado sobre ${formatNumber(storeKpis.numVendas)} vendas`}
          icon={Receipt}
          status="neutro"
          trend={{
            direction: 'up',
            text: 'Média global da loja',
          }}
        />

        {/* 6. Nº DE VENDAS */}
        <StatCard
          title="Nº de Vendas"
          value={formatNumber(storeKpis.numVendas)}
          subtitle={`~${Math.round(storeKpis.numVendas / storeKpis.diasDecorridos)} atendimentos/dia`}
          icon={ShoppingBag}
          status="neutro"
        />

        {/* 7. PROJEÇÃO */}
        <StatCard
          title="Projeção de Fechamento"
          value={formatCurrency(storeKpis.projecao)}
          subtitle={`Meta: ${formatCurrency(storeKpis.meta)}`}
          icon={TrendingUp}
          status={storeKpis.projecao >= storeKpis.meta ? 'positivo' : 'negativo'}
          trend={{
            direction: storeKpis.projecao >= storeKpis.meta ? 'up' : 'down',
            text: storeKpis.projecao >= storeKpis.meta ? 'ACIMA DA META' : 'ABAIXO DA META',
          }}
          className="sm:col-span-2 lg:col-span-2"
        />
      </div>

      {/* Section 17: Grande Indicador Principal de Meta */}
      <TargetGauge
        title="META DA LOJA — GARDEN CENTER"
        meta={storeKpis.meta}
        realizado={storeKpis.realizado}
        statusRitmo={storeKpis.statusRitmo}
        ritmoAtual={storeKpis.ritmoAtual}
        ritmoNecessario={storeKpis.ritmoNecessario}
        projecao={storeKpis.projecao}
      />

      {/* Section 18: Gráfico Principal de Linhas (Faturamento Acumulado x Meta Acumulada) */}
      <SalesTrendChart
        data={dailyData}
        title="Faturamento Acumulado × Meta Acumulada"
        subtitle="Acompanhe a curva de vendas contra a linha ideal da meta de R$ 400.000"
      />

      {/* Section 20: Quebra Semanal */}
      <WeeklyBreakdownCard
        weeks={weeklyBreakdown}
        title="Quebra Semanal da Meta da Loja"
        type="loja"
      />

      {/* Quick Team Banner Bridge */}
      <div className="rounded-2xl border border-white/[0.08] bg-gradient-to-r from-emerald-950/20 via-black to-emerald-950/20 p-5 lg:p-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-[11px] font-bold text-[#35C759] uppercase tracking-wider block mb-1">
            Destaque da Equipe de Vendas
          </span>
          <h4 className="text-lg font-bold text-white">
            Meta Coletiva: {formatCurrency(teamKpis.meta)} | Realizado: {formatCurrency(teamKpis.realizado)} ({formatPercent(teamKpis.atingimentoPercent)})
          </h4>
          <p className="text-xs text-[#8A8A8A] mt-1">
            {teamKpis.bonusElegivel
              ? `🔥 Meta batida! Bônus coletivo de ${formatCurrency(teamKpis.bonusTotal)} desbloqueado (${teamKpis.pontos} pontos acumulados).`
              : `Faltam ${formatCurrency(teamKpis.falta)} para destravar o bônus de R$ 600 coletivo.`}
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onNavigateTo('equipe')}
            className="px-4 py-2 rounded-xl bg-white/[0.08] hover:bg-white/[0.15] text-white text-xs font-semibold transition-all border border-white/10"
          >
            Ver Painel da Equipe
          </button>
          <button
            onClick={onOpenNewEntry}
            className="px-4 py-2 rounded-xl bg-[#35C759] hover:bg-[#2db34e] text-black text-xs font-bold transition-all shadow-[0_0_15px_rgba(53,199,89,0.3)]"
          >
            + Novo Lançamento
          </button>
        </div>
      </div>
    </div>
  );
};
