import React from 'react';
import { formatCurrency, formatPercent } from '../../utils/formatters';
import { clsx } from 'clsx';
import { TrendingUp, AlertTriangle, CheckCircle2, Flame } from 'lucide-react';

interface TargetGaugeProps {
  title: string;
  meta: number;
  realizado: number;
  statusRitmo: 'positivo' | 'alerta' | 'negativo';
  ritmoAtual: number;
  ritmoNecessario: number;
  projecao: number;
}

export const TargetGauge: React.FC<TargetGaugeProps> = ({
  title,
  meta,
  realizado,
  statusRitmo,
  ritmoAtual,
  ritmoNecessario,
  projecao,
}) => {
  const percent = meta > 0 ? (realizado / meta) * 100 : 0;
  const clampedPercent = Math.min(100, Math.max(0, percent));
  const gap = Math.max(0, meta - realizado);

  const getStatusTheme = () => {
    switch (statusRitmo) {
      case 'positivo':
        return {
          textColor: 'text-[#35C759]',
          borderColor: 'border-[#35C759]/30',
          gradient: 'from-[#1F8F4C] to-[#35C759]',
          glow: 'shadow-[0_0_20px_rgba(53,199,89,0.35)]',
          badgeText: 'Ritmo Positivo (Superando)',
          badgeClass: 'bg-[#35C759]/15 text-[#35C759] border-[#35C759]/30',
          icon: <Flame className="w-4 h-4 text-[#35C759]" />,
        };
      case 'alerta':
        return {
          textColor: 'text-[#F5C542]',
          borderColor: 'border-[#F5C542]/30',
          gradient: 'from-[#D97706] to-[#F5C542]',
          glow: 'shadow-[0_0_20px_rgba(245,197,66,0.35)]',
          badgeText: 'Em Alerta (Acelerar)',
          badgeClass: 'bg-[#F5C542]/15 text-[#F5C542] border-[#F5C542]/30',
          icon: <AlertTriangle className="w-4 h-4 text-[#F5C542]" />,
        };
      case 'negativo':
      default:
        return {
          textColor: 'text-[#FF453A]',
          borderColor: 'border-[#FF453A]/30',
          gradient: 'from-[#B91C1C] to-[#FF453A]',
          glow: 'shadow-[0_0_20px_rgba(255,69,58,0.35)]',
          badgeText: 'Abaixo do Ritmo',
          badgeClass: 'bg-[#FF453A]/15 text-[#FF453A] border-[#FF453A]/30',
          icon: <AlertTriangle className="w-4 h-4 text-[#FF453A]" />,
        };
    }
  };

  const theme = getStatusTheme();

  return (
    <div className={clsx('relative rounded-2xl border bg-white/[0.03] backdrop-blur-md p-6 overflow-hidden transition-all', theme.borderColor)}>
      {/* Background ambient lighting */}
      <div
        className={clsx(
          'absolute -right-20 -top-20 w-64 h-64 rounded-full blur-3xl pointer-events-none opacity-20',
          statusRitmo === 'positivo' && 'bg-[#35C759]',
          statusRitmo === 'alerta' && 'bg-[#F5C542]',
          statusRitmo === 'negativo' && 'bg-[#FF453A]'
        )}
      />

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
        <div>
          <span className="text-[11px] font-bold uppercase tracking-widest text-[#8A8A8A]">
            Indicador Principal de Desempenho
          </span>
          <h3 className="text-xl lg:text-2xl font-black text-white tracking-tight flex items-center gap-2 mt-0.5">
            {title}
          </h3>
        </div>

        <div className="flex items-center gap-2">
          <span className={clsx('inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border', theme.badgeClass)}>
            {theme.icon}
            {theme.badgeText}
          </span>
        </div>
      </div>

      {/* Main KPI Numbers: Realizado vs Meta */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
          <span className="text-xs text-[#8A8A8A] font-semibold uppercase tracking-wider block mb-1">
            Realizado
          </span>
          <span className="text-2xl lg:text-3xl font-extrabold text-white">
            {formatCurrency(realizado)}
          </span>
          <span className="text-xs text-[#8A8A8A] block mt-1">
            Faturamento computado até hoje
          </span>
        </div>

        <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
          <span className="text-xs text-[#8A8A8A] font-semibold uppercase tracking-wider block mb-1">
            Meta Estabelecida
          </span>
          <span className="text-2xl lg:text-3xl font-extrabold text-white">
            {formatCurrency(meta)}
          </span>
          <span className="text-xs text-[#8A8A8A] block mt-1">
            Alvo total do período
          </span>
        </div>

        <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
          <span className="text-xs text-[#8A8A8A] font-semibold uppercase tracking-wider block mb-1">
            Atingimento
          </span>
          <span className={clsx('text-2xl lg:text-3xl font-extrabold', theme.textColor)}>
            {formatPercent(percent)}
          </span>
          <span className="text-xs text-[#8A8A8A] block mt-1">
            {gap > 0 ? `Falta ${formatCurrency(gap)}` : 'Meta superada!'}
          </span>
        </div>
      </div>

      {/* Big Visual Horizontal Progress Bar (Section 17) */}
      <div className="mb-4">
        <div className="flex items-center justify-between text-xs mb-2">
          <span className="text-[#8A8A8A] font-medium">Progresso da Meta:</span>
          <span className={clsx('font-extrabold text-base', theme.textColor)}>
            {formatPercent(percent)}
          </span>
        </div>

        <div className="w-full bg-white/[0.06] rounded-full h-5 p-1 border border-white/[0.08] relative overflow-hidden">
          {/* Subtle grid ticks on bar */}
          <div className="absolute inset-0 flex justify-between px-2 pointer-events-none opacity-20">
            <span className="border-r border-white h-full" />
            <span className="border-r border-white h-full" />
            <span className="border-r border-white h-full" />
            <span className="border-r border-white h-full" />
          </div>

          <div
            className={clsx(
              'h-full rounded-full transition-all duration-1000 ease-out bg-gradient-to-r relative',
              theme.gradient,
              theme.glow
            )}
            style={{ width: `${clampedPercent}%` }}
          />
        </div>
      </div>

      {/* Mini Pace Summary Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-4 border-t border-white/[0.06] text-xs">
        <div>
          <span className="text-[#8A8A8A] block">Ritmo Diário Atual:</span>
          <span className="font-bold text-white text-sm">
            {formatCurrency(ritmoAtual)}/dia
          </span>
        </div>
        <div>
          <span className="text-[#8A8A8A] block">Necessário por Dia:</span>
          <span className={clsx('font-bold text-sm', gap > 0 ? 'text-[#F5C542]' : 'text-[#35C759]')}>
            {gap > 0 ? `${formatCurrency(ritmoNecessario)}/dia` : 'Meta Batida'}
          </span>
        </div>
        <div className="col-span-2 sm:col-span-1">
          <span className="text-[#8A8A8A] block">Projeção de Fechamento:</span>
          <span className={clsx('font-bold text-sm', projecao >= meta ? 'text-[#35C759]' : 'text-[#FF453A]')}>
            {formatCurrency(projecao)}
          </span>
        </div>
      </div>
    </div>
  );
};
