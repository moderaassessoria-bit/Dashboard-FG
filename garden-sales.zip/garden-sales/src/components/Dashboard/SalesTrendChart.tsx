import React, { useState } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Area,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
  ReferenceLine,
} from 'recharts';
import { formatCurrency, formatCompactCurrency } from '../../utils/formatters';
import { clsx } from 'clsx';

interface DailyDataPoint {
  dia: string;
  diaNum: number;
  metaDiaria: number;
  metaAcumulada: number;
  realizadoDia: number | null;
  realizadoAcumulado: number | null;
  isFuture: boolean;
  gap: number | null;
}

interface SalesTrendChartProps {
  data: DailyDataPoint[];
  title?: string;
  subtitle?: string;
}

export const SalesTrendChart: React.FC<SalesTrendChartProps> = ({
  data,
  title = 'Faturamento Acumulado × Meta Acumulada',
  subtitle = 'Evolução comparativa dia a dia do mês atual',
}) => {
  const [chartMode, setChartMode] = useState<'acumulado' | 'diario'>('acumulado');

  // Custom Dark Tooltip
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const pData = payload[0].payload as DailyDataPoint;
      return (
        <div className="bg-[#121212] border border-white/10 rounded-xl p-3.5 shadow-2xl backdrop-blur-md text-xs">
          <p className="font-bold text-white text-sm mb-2">{label}</p>
          <div className="space-y-1.5">
            {chartMode === 'acumulado' ? (
              <>
                <div className="flex items-center justify-between gap-4">
                  <span className="text-[#8A8A8A] flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-[#35C759]" />
                    Realizado Acumulado:
                  </span>
                  <span className="font-mono font-bold text-white">
                    {pData.realizadoAcumulado !== null ? formatCurrency(pData.realizadoAcumulado) : 'Não decorrido'}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-4">
                  <span className="text-[#8A8A8A] flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-white/40" />
                    Meta Acumulada:
                  </span>
                  <span className="font-mono font-bold text-white/80">
                    {formatCurrency(pData.metaAcumulada)}
                  </span>
                </div>
                {pData.gap !== null && (
                  <div className="flex items-center justify-between gap-4 pt-1.5 border-t border-white/[0.08]">
                    <span className="text-[#8A8A8A]">Diferença (Gap):</span>
                    <span
                      className={clsx(
                        'font-mono font-bold',
                        pData.gap >= 0 ? 'text-[#35C759]' : 'text-[#FF453A]'
                      )}
                    >
                      {pData.gap >= 0 ? '+' : ''}{formatCurrency(pData.gap)}
                    </span>
                  </div>
                )}
              </>
            ) : (
              <>
                <div className="flex items-center justify-between gap-4">
                  <span className="text-[#8A8A8A] flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-[#35C759]" />
                    Realizado no Dia:
                  </span>
                  <span className="font-mono font-bold text-white">
                    {pData.realizadoDia !== null ? formatCurrency(pData.realizadoDia) : 'Não decorrido'}
                  </span>
                </div>
                <div className="flex items-center justify-between gap-4">
                  <span className="text-[#8A8A8A] flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-white/40" />
                    Meta Diária Linear:
                  </span>
                  <span className="font-mono font-bold text-white/80">
                    {formatCurrency(pData.metaDiaria)}
                  </span>
                </div>
              </>
            )}
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-5 lg:p-6 transition-all">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
        <div>
          <h3 className="text-base lg:text-lg font-bold text-white tracking-tight">
            {title}
          </h3>
          <p className="text-xs text-[#8A8A8A] mt-0.5">{subtitle}</p>
        </div>

        {/* Chart View Switcher */}
        <div className="flex items-center bg-black/40 p-0.5 rounded-lg border border-white/[0.04] self-start sm:self-auto">
          <button
            onClick={() => setChartMode('acumulado')}
            className={clsx(
              'px-3 py-1.5 text-xs font-semibold rounded-md transition-all',
              chartMode === 'acumulado'
                ? 'bg-[#35C759]/20 text-[#35C759] border border-[#35C759]/30'
                : 'text-[#8A8A8A] hover:text-white'
            )}
          >
            Acumulado
          </button>
          <button
            onClick={() => setChartMode('diario')}
            className={clsx(
              'px-3 py-1.5 text-xs font-semibold rounded-md transition-all',
              chartMode === 'diario'
                ? 'bg-[#35C759]/20 text-[#35C759] border border-[#35C759]/30'
                : 'text-[#8A8A8A] hover:text-white'
            )}
          >
            Diário
          </button>
        </div>
      </div>

      <div className="h-72 lg:h-80 w-full">
        <ResponsiveContainer width="100%" height="100%">
          {chartMode === 'acumulado' ? (
            <ComposedChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="realizadoGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#35C759" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#35C759" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
              <XAxis
                dataKey="dia"
                tick={{ fill: '#8A8A8A', fontSize: 11 }}
                axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                tickLine={false}
              />
              <YAxis
                tickFormatter={(v) => formatCompactCurrency(v)}
                tick={{ fill: '#8A8A8A', fontSize: 11 }}
                axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                tickLine={false}
                width={65}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="top"
                align="right"
                wrapperStyle={{ paddingBottom: '12px', fontSize: '11px' }}
              />
              {/* Target Line */}
              <Line
                name="Meta Acumulada"
                type="monotone"
                dataKey="metaAcumulada"
                stroke="rgba(255,255,255,0.35)"
                strokeDasharray="4 4"
                strokeWidth={2}
                dot={false}
              />
              {/* Actual Line + Area */}
              <Area
                name="Realizado Acumulado"
                type="monotone"
                dataKey="realizadoAcumulado"
                stroke="#35C759"
                strokeWidth={3}
                fillOpacity={1}
                fill="url(#realizadoGradient)"
                dot={{ r: 3, fill: '#35C759', stroke: '#050505', strokeWidth: 1 }}
                activeDot={{ r: 6, fill: '#35C759', stroke: '#FFFFFF', strokeWidth: 2 }}
              />
            </ComposedChart>
          ) : (
            <ComposedChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
              <XAxis
                dataKey="dia"
                tick={{ fill: '#8A8A8A', fontSize: 11 }}
                axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                tickLine={false}
              />
              <YAxis
                tickFormatter={(v) => formatCompactCurrency(v)}
                tick={{ fill: '#8A8A8A', fontSize: 11 }}
                axisLine={{ stroke: 'rgba(255,255,255,0.1)' }}
                tickLine={false}
                width={65}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="top"
                align="right"
                wrapperStyle={{ paddingBottom: '12px', fontSize: '11px' }}
              />
              <Line
                name="Meta Diária Linear"
                type="monotone"
                dataKey="metaDiaria"
                stroke="rgba(255,255,255,0.35)"
                strokeDasharray="3 3"
                strokeWidth={2}
                dot={false}
              />
              <Bar
                name="Realizado no Dia"
                dataKey="realizadoDia"
                fill="#35C759"
                radius={[4, 4, 0, 0]}
              />
            </ComposedChart>
          )}
        </ResponsiveContainer>
      </div>
    </div>
  );
};
