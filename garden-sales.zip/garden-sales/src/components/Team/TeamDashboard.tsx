import React from 'react';
import { TeamKpis, SystemConfig, SaleEntry, WeeklyBreakdown } from '../../types';
import { formatCurrency, formatPercent, formatNumber } from '../../utils/formatters';
import { ProgressBar } from '../Common/ProgressBar';
import { SalesTrendChart } from '../Dashboard/SalesTrendChart';
import { WeeklyBreakdownCard } from '../Dashboard/WeeklyBreakdownCard';
import { computeDailyAccumulated, computeWeeklyBreakdown } from '../../utils/calculations';
import { clsx } from 'clsx';
import {
  Trophy,
  Award,
  Users,
  Target,
  Flame,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  TrendingUp,
  Receipt,
  ShoppingBag,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface TeamDashboardProps {
  teamKpis: TeamKpis;
  config: SystemConfig;
  entries: SaleEntry[];
  onOpenNewEntry: () => void;
}

export const TeamDashboard: React.FC<TeamDashboardProps> = ({
  teamKpis,
  config,
  entries,
  onOpenNewEntry,
}) => {
  // Only filter entries from sales team (Alessandra, Felipe, Arnaldo)
  const teamSellerNames = ['alessandra', 'felipe', 'arnaldo'];
  const teamEntries = entries.filter((e) =>
    teamSellerNames.includes(e.vendedor.toLowerCase())
  );

  const teamWeekly = computeWeeklyBreakdown(teamEntries, config, 'equipe');
  const teamDaily = computeDailyAccumulated(teamEntries, config, 'equipe');

  const triggerCelebration = () => {
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#35C759', '#1F8F4C', '#F5C542', '#FFFFFF'],
    });
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Privacy Notice Banner (#4 & #21) */}
      <div className="p-3.5 rounded-xl bg-blue-500/[0.08] border border-blue-500/20 text-blue-300 flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-blue-400 shrink-0" />
          <span>
            <strong>Painel Coletivo da Equipe:</strong> Focado na união e conquista coletiva.
            Os resultados individuais são confidenciais e protegidos nesta tela.
          </span>
        </div>
        {teamKpis.bonusElegivel && (
          <button
            onClick={triggerCelebration}
            className="px-2.5 py-1 rounded bg-[#35C759]/20 hover:bg-[#35C759]/30 text-[#35C759] border border-[#35C759]/30 font-semibold text-[11px] shrink-0 transition-colors flex items-center gap-1"
          >
            <Sparkles className="w-3 h-3" />
            Comemorar!
          </button>
        )}
      </div>

      {/* Section 21: KPIs da Equipe */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Meta da Equipe */}
        <div className="rounded-xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-5">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A] block mb-1">
            Meta Coletiva
          </span>
          <span className="text-2xl lg:text-3xl font-extrabold text-white block">
            {formatCurrency(teamKpis.meta)}
          </span>
          <span className="text-xs text-[#8A8A8A] mt-1 block">
            Média histórica: {formatCurrency(config.mediaHistoricaEquipe)}
          </span>
        </div>

        {/* Realizado */}
        <div className="rounded-xl border border-[#35C759]/30 bg-white/[0.03] backdrop-blur-md p-5 shadow-[0_0_20px_rgba(53,199,89,0.08)]">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A]">
              Realizado Equipe
            </span>
            <span className="text-xs font-bold text-[#35C759]">
              {formatPercent(teamKpis.atingimentoPercent)}
            </span>
          </div>
          <span className="text-2xl lg:text-3xl font-extrabold text-[#35C759] block">
            {formatCurrency(teamKpis.realizado)}
          </span>
          <span className="text-xs text-[#8A8A8A] mt-1 block">
            Produzido pelos 3 vendedores juntos
          </span>
        </div>

        {/* Falta para a Meta */}
        <div className="rounded-xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-5">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A]">
              Falta Para Meta
            </span>
            <span className="text-xs font-bold text-[#FF453A]">
              {formatPercent(teamKpis.faltaPercent)}
            </span>
          </div>
          <span className={clsx('text-2xl lg:text-3xl font-extrabold block', teamKpis.falta === 0 ? 'text-[#35C759]' : 'text-white')}>
            {teamKpis.falta === 0 ? 'Meta Batida! 🏆' : formatCurrency(teamKpis.falta)}
          </span>
          <span className="text-xs text-[#8A8A8A] mt-1 block">
            {teamKpis.falta === 0 ? 'Equipe no topo!' : `Necessário ${formatCurrency(teamKpis.ritmoNecessario)}/dia`}
          </span>
        </div>

        {/* Vendas e Ticket Médio */}
        <div className="rounded-xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-5">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#8A8A8A] block">
                Nº Vendas
              </span>
              <span className="text-xl font-extrabold text-white">
                {formatNumber(teamKpis.numVendas)}
              </span>
              <span className="text-[10px] text-[#8A8A8A] block">vendas totais</span>
            </div>
            <div>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#8A8A8A] block">
                Ticket Médio
              </span>
              <span className="text-xl font-extrabold text-[#35C759]">
                {formatCurrency(teamKpis.ticketMedio)}
              </span>
              <span className="text-[10px] text-[#8A8A8A] block">por venda</span>
            </div>
          </div>
        </div>
      </div>

      {/* Section 22: Grande Indicador de Progresso da Equipe */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <span className="text-xs font-bold text-[#35C759] uppercase tracking-wider">
              Objetivo do Mês
            </span>
            <h3 className="text-2xl font-black text-white tracking-tight mt-0.5">
              META DA EQUIPE — R$ 155.000
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <span
              className={clsx(
                'px-3 py-1 rounded-full text-xs font-bold border uppercase tracking-wider',
                teamKpis.atingimentoPercent >= 100
                  ? 'bg-[#35C759]/15 text-[#35C759] border-[#35C759]/30'
                  : teamKpis.atingimentoPercent >= 85
                  ? 'bg-[#F5C542]/15 text-[#F5C542] border-[#F5C542]/30'
                  : 'bg-[#FF453A]/15 text-[#FF453A] border-[#FF453A]/30'
              )}
            >
              {teamKpis.atingimentoPercent >= 100
                ? 'Conquistado'
                : `Falta ${formatPercent(teamKpis.faltaPercent)}`}
            </span>
          </div>
        </div>

        {/* Clear visual split: Quanto Já Produzimos vs Quanto Falta */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div className="p-4 rounded-xl bg-[#35C759]/10 border border-[#35C759]/30">
            <span className="text-xs font-bold text-[#35C759] uppercase tracking-wider block mb-1">
              Quanto já produzimos
            </span>
            <span className="text-3xl font-extrabold text-white">
              {formatCurrency(teamKpis.realizado)}
            </span>
            <p className="text-xs text-[#8A8A8A] mt-1">
              {formatPercent(teamKpis.atingimentoPercent)} do desafio coletivo conquistado
            </p>
          </div>

          <div className="p-4 rounded-xl bg-black/40 border border-white/[0.08]">
            <span className="text-xs font-bold text-[#8A8A8A] uppercase tracking-wider block mb-1">
              Quanto falta
            </span>
            <span className="text-3xl font-extrabold text-white">
              {formatCurrency(teamKpis.falta)}
            </span>
            <p className="text-xs text-[#8A8A8A] mt-1">
              {teamKpis.falta === 0 ? 'Desafio 100% cumprido!' : `Restam ${formatCurrency(teamKpis.ritmoNecessario)}/dia para alcançar`}
            </p>
          </div>
        </div>

        {/* Big Progress Bar */}
        <ProgressBar
          current={teamKpis.realizado}
          target={teamKpis.meta}
          size="lg"
          showPercent={true}
        />
      </div>

      {/* Section 23: Sistema de Pontos da Equipe & Seção 5: Bonificação Coletiva */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Card de Pontos (#6 & #23) */}
        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6 relative overflow-hidden">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <Trophy className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-base font-bold text-white tracking-tight">
                  Sistema de Pontos Extras
                </h4>
                <p className="text-xs text-[#8A8A8A]">
                  Acima de R$ 155k: cada +10% = +100 pontos (≈ R$ 100)
                </p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold px-2 py-1 rounded bg-amber-500/15 text-amber-400 border border-amber-500/30">
              NÍVEL {Math.floor(teamKpis.pontos / 100)}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-4">
            <div className="p-3 rounded-xl bg-black/40 border border-white/[0.06]">
              <span className="text-[10px] font-bold text-[#8A8A8A] uppercase block">
                Pontos
              </span>
              <span className="text-2xl font-black text-amber-400">
                {teamKpis.pontos}
              </span>
              <span className="text-[10px] text-[#8A8A8A] block">acumulados</span>
            </div>

            <div className="p-3 rounded-xl bg-black/40 border border-white/[0.06]">
              <span className="text-[10px] font-bold text-[#8A8A8A] uppercase block">
                Valor Estimado
              </span>
              <span className="text-2xl font-black text-[#35C759]">
                {formatCurrency(teamKpis.valorPontos)}
              </span>
              <span className="text-[10px] text-[#8A8A8A] block">em premiação</span>
            </div>

            <div className="p-3 rounded-xl bg-black/40 border border-white/[0.06]">
              <span className="text-[10px] font-bold text-[#8A8A8A] uppercase block">
                Próximo Nível
              </span>
              <span className="text-sm font-extrabold text-white truncate block">
                {formatCurrency(teamKpis.proximoNivelMeta)}
              </span>
              <span className="text-[10px] text-[#8A8A8A] block">+100 pts</span>
            </div>

            <div className="p-3 rounded-xl bg-black/40 border border-white/[0.06]">
              <span className="text-[10px] font-bold text-[#8A8A8A] uppercase block">
                Falta p/ Próx. Nível
              </span>
              <span className="text-sm font-extrabold text-[#F5C542] truncate block">
                {formatCurrency(teamKpis.faltaProximoNivel)}
              </span>
              <span className="text-[10px] text-[#8A8A8A] block">a produzir</span>
            </div>
          </div>

          <div className="pt-3 border-t border-white/[0.06] text-xs text-[#8A8A8A]">
            <p>
              Tabela de Progressão: R$ 155k (Meta) ➔ +10% (R$ 170.500 = 100 pts) ➔ +20% (R$ 186.000 = 200 pts) ➔ +30% (R$ 201.500 = 300 pts).
            </p>
          </div>
        </div>

        {/* Section 5: Bonificação da Equipe */}
        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6 relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-base font-bold text-white tracking-tight">
                    Bonificação Coletiva da Equipe
                  </h4>
                  <p className="text-xs text-[#8A8A8A]">
                    R$ 200 para cada vendedor ao bater a meta de R$ 155k
                  </p>
                </div>
              </div>

              <span
                className={clsx(
                  'px-2.5 py-1 rounded-full text-xs font-bold border',
                  teamKpis.bonusElegivel
                    ? 'bg-[#35C759]/20 text-[#35C759] border-[#35C759]/30'
                    : 'bg-white/[0.06] text-[#8A8A8A] border-white/10'
                )}
              >
                {teamKpis.bonusElegivel ? 'LIBERADO' : 'EM DISPUTA'}
              </span>
            </div>

            <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06] mb-4">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-[#8A8A8A]">Bônus Total Coletivo:</span>
                <span className="text-xl font-bold text-white">
                  3 × R$ 200 = <span className="text-[#35C759]">R$ 600,00</span>
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-[#8A8A8A] pt-2 border-t border-white/[0.04]">
                <span>Status da Conquista:</span>
                <span className={clsx('font-semibold', teamKpis.bonusElegivel ? 'text-[#35C759]' : 'text-[#F5C542]')}>
                  {teamKpis.bonusElegivel ? 'Meta batida! Cada um garantiu R$ 200!' : `Faltam ${formatCurrency(teamKpis.falta)}`}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-white/[0.06]">
            <span className="text-xs text-[#8A8A8A]">
              Alessandra • Felipe • Arnaldo
            </span>
            <button
              onClick={onOpenNewEntry}
              className="px-3.5 py-1.5 rounded-lg bg-[#35C759] hover:bg-[#2db34e] text-black text-xs font-bold transition-all shadow-[0_0_12px_rgba(53,199,89,0.3)]"
            >
              + Lançar Venda
            </button>
          </div>
        </div>
      </div>

      {/* Gráfico da Equipe */}
      <SalesTrendChart
        data={teamDaily}
        title="Evolução Coletiva da Equipe (R$ 155k)"
        subtitle="Acompanhamento diário das vendas da equipe contra a meta de R$ 155.000"
      />

      {/* Quebra Semanal da Equipe */}
      <WeeklyBreakdownCard
        weeks={teamWeekly}
        title="Quebra Semanal da Equipe"
        type="equipe"
      />
    </div>
  );
};
