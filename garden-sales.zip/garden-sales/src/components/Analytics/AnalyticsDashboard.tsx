import React, { useState } from 'react';
import { SaleEntry, SystemConfig, StoreKpis, TeamKpis } from '../../types';
import { formatCurrency, formatPercent, formatNumber } from '../../utils/formatters';
import { calculateTicket } from '../../utils/calculations';
import { clsx } from 'clsx';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import {
  Receipt,
  ShoppingBag,
  TrendingUp,
  TrendingDown,
  Calendar,
  Layers,
  ArrowUpRight,
  PieChart,
} from 'lucide-react';

interface AnalyticsDashboardProps {
  entries: SaleEntry[];
  config: SystemConfig;
  storeKpis: StoreKpis;
  teamKpis: TeamKpis;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  entries,
  config,
  storeKpis,
  teamKpis,
}) => {
  // Aggregate daily metrics
  const daysMap = new Map<number, { faturamento: number; vendas: number }>();
  entries.forEach((e) => {
    let day = 0;
    if (e.data.includes('-')) day = parseInt(e.data.split('-')[2], 10);
    else if (e.data.includes('/')) day = parseInt(e.data.split('/')[0], 10);
    if (!daysMap.has(day)) daysMap.set(day, { faturamento: 0, vendas: 0 });
    const current = daysMap.get(day)!;
    current.faturamento += e.faturamento;
    current.vendas += e.numVendas;
  });

  const diasDecorridos = config.diasDecorridos || 24;
  const dailyEvolution = [];
  let totalTicketAcum = 0;
  let countWithSales = 0;

  for (let d = 1; d <= diasDecorridos; d++) {
    const data = daysMap.get(d) || { faturamento: 0, vendas: 0 };
    const ticket = calculateTicket(data.faturamento, data.vendas);
    if (data.vendas > 0) {
      totalTicketAcum += ticket;
      countWithSales++;
    }

    dailyEvolution.push({
      dia: `Dia ${d}`,
      diaNum: d,
      faturamento: data.faturamento,
      vendas: data.vendas,
      ticket: ticket > 0 ? ticket : null,
      ticketReferencia: 125, // Referência do Garden Center
    });
  }

  // Day of week analysis (Garden Center pattern: Sábados e Domingos vendem mais)
  const dayOfWeekNames = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
  const dowTotals = [0, 1, 2, 3, 4, 5, 6].map((dow) => ({
    dow,
    nome: dayOfWeekNames[dow],
    faturamento: 0,
    vendas: 0,
    ticketMedio: 0,
    count: 0,
  }));

  entries.forEach((e) => {
    const dateObj = new Date(e.data.includes('/') ? e.data.split('/').reverse().join('-') : e.data);
    const dow = dateObj.getDay();
    if (dowTotals[dow]) {
      dowTotals[dow].faturamento += e.faturamento;
      dowTotals[dow].vendas += e.numVendas;
      dowTotals[dow].count++;
    }
  });

  dowTotals.forEach((d) => {
    d.ticketMedio = calculateTicket(d.faturamento, d.vendas);
  });

  const mediaVendasSemanal = Math.round((storeKpis.numVendas / diasDecorridos) * 7);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Top Banner */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6">
        <h3 className="text-xl font-bold text-white tracking-tight">
          Análises Comerciais Avançadas
        </h3>
        <p className="text-xs text-[#8A8A8A] mt-1">
          Inteligência de Ticket Médio, volume transacional e sazonalidade do Garden Center
        </p>
      </div>

      {/* Section 29: Módulo TICKET MÉDIO */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-white/[0.08]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#35C759]/10 text-[#35C759] border border-[#35C759]/20">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#35C759]">
                Módulo Comercial
              </span>
              <h4 className="text-lg font-bold text-white">TICKET MÉDIO</h4>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <span className="text-[10px] text-[#8A8A8A] block">Ticket Atual da Loja:</span>
              <span className="text-xl font-extrabold text-[#35C759]">
                {formatCurrency(storeKpis.ticketMedio)}
              </span>
            </div>
          </div>
        </div>

        {/* 4 KPIs do Ticket Médio */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              Ticket Médio Atual
            </span>
            <span className="text-2xl font-bold text-white block mt-1">
              {formatCurrency(storeKpis.ticketMedio)}
            </span>
            <span className="text-[10px] text-[#35C759] block mt-1">Geral da Loja</span>
          </div>

          <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              Ticket da Equipe
            </span>
            <span className="text-2xl font-bold text-[#35C759] block mt-1">
              {formatCurrency(teamKpis.ticketMedio)}
            </span>
            <span className="text-[10px] text-[#8A8A8A] block mt-1">Venda consultiva</span>
          </div>

          <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              Meta / Referência
            </span>
            <span className="text-2xl font-bold text-white/80 block mt-1">
              R$ 125,00
            </span>
            <span className="text-[10px] text-[#35C759] block mt-1">+3,2% sobre ref.</span>
          </div>

          <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              Variação Período
            </span>
            <span className="text-2xl font-bold text-[#35C759] block mt-1">
              +4,8%
            </span>
            <span className="text-[10px] text-[#8A8A8A] block mt-1">em crescimento</span>
          </div>
        </div>

        {/* Gráfico de Evolução do Ticket Médio */}
        <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
          <h5 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
            Evolução Diária do Ticket Médio (R$) vs Linha de Referência
          </h5>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={dailyEvolution}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                <XAxis dataKey="dia" tick={{ fill: '#8A8A8A', fontSize: 11 }} tickLine={false} />
                <YAxis tick={{ fill: '#8A8A8A', fontSize: 11 }} tickLine={false} width={45} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#121212', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px' }}
                  formatter={(val: any) => formatCurrency(Number(val))}
                />
                <Legend verticalAlign="top" align="right" wrapperStyle={{ paddingBottom: '10px', fontSize: '11px' }} />
                <Line
                  name="Linha de Referência (R$ 125,00)"
                  type="monotone"
                  dataKey="ticketReferencia"
                  stroke="rgba(255,255,255,0.3)"
                  strokeDasharray="3 3"
                  dot={false}
                />
                <Line
                  name="Ticket Médio Realizado (R$)"
                  type="monotone"
                  dataKey="ticket"
                  stroke="#35C759"
                  strokeWidth={2.5}
                  dot={{ r: 3, fill: '#35C759' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Section 30: Módulo NÚMERO DE VENDAS */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-white/[0.08]">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-blue-400">
                Módulo de Volume
              </span>
              <h4 className="text-lg font-bold text-white">NÚMERO DE VENDAS</h4>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-[#8A8A8A] block">Total de Vendas Acumulado:</span>
            <span className="text-xl font-extrabold text-white">
              {formatNumber(storeKpis.numVendas)} atendimentos
            </span>
          </div>
        </div>

        {/* 4 KPIs de Vendas */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              Total de Vendas
            </span>
            <span className="text-2xl font-bold text-white block mt-1">
              {formatNumber(storeKpis.numVendas)}
            </span>
            <span className="text-[10px] text-[#8A8A8A] block mt-1">no mês de referência</span>
          </div>

          <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              Média Diária
            </span>
            <span className="text-2xl font-bold text-blue-400 block mt-1">
              {Math.round(storeKpis.numVendas / diasDecorridos)}
            </span>
            <span className="text-[10px] text-[#8A8A8A] block mt-1">vendas por dia</span>
          </div>

          <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              Média Semanal
            </span>
            <span className="text-2xl font-bold text-white block mt-1">
              {formatNumber(mediaVendasSemanal)}
            </span>
            <span className="text-[10px] text-[#8A8A8A] block mt-1">vendas a cada 7 dias</span>
          </div>

          <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              Projeção de Vendas
            </span>
            <span className="text-2xl font-bold text-[#35C759] block mt-1">
              {formatNumber(Math.round((storeKpis.numVendas / diasDecorridos) * config.diasOperacionais))}
            </span>
            <span className="text-[10px] text-[#8A8A8A] block mt-1">fechamento projetado</span>
          </div>
        </div>

        {/* Gráfico de Volume de Vendas Diário */}
        <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
          <h5 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
            Volume de Transações Concluídas por Dia
          </h5>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dailyEvolution}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                <XAxis dataKey="dia" tick={{ fill: '#8A8A8A', fontSize: 11 }} tickLine={false} />
                <YAxis tick={{ fill: '#8A8A8A', fontSize: 11 }} tickLine={false} width={35} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#121212', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px' }}
                />
                <Bar dataKey="vendas" name="Nº de Vendas" fill="#3B82F6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Sazonalidade por Dia da Semana (Comportamento Típico de Garden Center) */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6">
        <h4 className="text-base font-bold text-white tracking-tight mb-2">
          Padrão de Faturamento por Dia da Semana
        </h4>
        <p className="text-xs text-[#8A8A8A] mb-4">
          Identifique os dias de maior fluxo e ticket no Garden Center (ex: fins de semana para jardinagem e paisagismo)
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-7 gap-3">
          {dowTotals.map((dow) => (
            <div
              key={dow.nome}
              className="p-3 rounded-xl bg-black/40 border border-white/[0.06] text-center"
            >
              <span className="text-[11px] font-bold text-white uppercase block mb-1">
                {dow.nome}
              </span>
              <span className="text-sm font-extrabold text-[#35C759] block">
                {formatCurrency(dow.faturamento)}
              </span>
              <span className="text-[10px] text-[#8A8A8A] block mt-1">
                {dow.vendas} vendas • Ticket {formatCurrency(dow.ticketMedio)}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
