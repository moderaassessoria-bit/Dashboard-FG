import React from 'react';
import { Modal } from '../Common/Modal';
import { SaleEntry, SystemConfig, StoreKpis } from '../../types';
import { formatCurrency, formatPercent, formatNumber, formatDateBr } from '../../utils/formatters';
import { calculateTicket } from '../../utils/calculations';
import { ProgressBar } from '../Common/ProgressBar';
import { clsx } from 'clsx';
import { Clock, Calendar, TrendingUp, AlertCircle, CheckCircle2 } from 'lucide-react';

interface TodayModalProps {
  isOpen: boolean;
  onClose: () => void;
  entries: SaleEntry[];
  config: SystemConfig;
  storeKpis: StoreKpis;
  targetDate?: string; // defaults to 2026-09-24
}

export const TodayModal: React.FC<TodayModalProps> = ({
  isOpen,
  onClose,
  entries,
  config,
  storeKpis,
  targetDate = '2026-09-24',
}) => {
  // Lançamentos de hoje
  const todayEntries = entries.filter((e) => e.data === targetDate);
  const realizadoHoje = todayEntries.reduce((acc, curr) => acc + curr.faturamento, 0);
  const vendasHoje = todayEntries.reduce((acc, curr) => acc + curr.numVendas, 0);
  const ticketHoje = calculateTicket(realizadoHoje, vendasHoje);

  // Metas do dia
  const metaDiaria = (config.metaLoja || 400000) / (config.diasOperacionais || 26);
  const atingimentoDiaPercent = metaDiaria > 0 ? (realizadoHoje / metaDiaria) * 100 : 0;
  const faltaDoDia = Math.max(0, metaDiaria - realizadoHoje);

  // Acumulados até hoje
  const diaNum = parseInt(targetDate.split('-')[2], 10) || 24;
  const metaAcumuladaAteHoje = metaDiaria * diaNum;
  const realizadoAcumuladoAteHoje = storeKpis.realizado;
  const gapAcumulado = realizadoAcumuladoAteHoje - metaAcumuladaAteHoje;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Visão Comercial de Hoje"
      subtitle={`Desempenho em tempo real do dia ${formatDateBr(targetDate)} (Dia ${diaNum} de ${config.diasOperacionais})`}
      maxWidth="xl"
    >
      <div className="space-y-6">
        {/* Banner do Dia */}
        <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/40 via-black to-emerald-950/40 border border-[#35C759]/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#35C759]/20 text-[#35C759]">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-[#35C759] uppercase tracking-wider block">
                Operação Diária
              </span>
              <h4 className="text-base font-bold text-white">
                Meta do Dia: {formatCurrency(metaDiaria)}
              </h4>
            </div>
          </div>

          <span
            className={clsx(
              'px-3 py-1 rounded-full text-xs font-bold border uppercase tracking-wider',
              atingimentoDiaPercent >= 100
                ? 'bg-[#35C759]/20 text-[#35C759] border-[#35C759]/30'
                : atingimentoDiaPercent >= 80
                ? 'bg-[#F5C542]/20 text-[#F5C542] border-[#F5C542]/30'
                : 'bg-[#FF453A]/20 text-[#FF453A] border-[#FF453A]/30'
            )}
          >
            {atingimentoDiaPercent >= 100 ? 'Meta Batida!' : `${formatPercent(atingimentoDiaPercent)} Atingido`}
          </span>
        </div>

        {/* Section 33: Grid de Indicadores de Hoje */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {/* Realizado Hoje */}
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              Realizado Hoje
            </span>
            <span className="text-xl font-black text-white block mt-0.5">
              {formatCurrency(realizadoHoje)}
            </span>
            <span className="text-[10px] text-[#8A8A8A] block mt-1">
              Faturamento registrado
            </span>
          </div>

          {/* % da Meta do Dia */}
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              % da Meta do Dia
            </span>
            <span
              className={clsx(
                'text-xl font-black block mt-0.5',
                atingimentoDiaPercent >= 100
                  ? 'text-[#35C759]'
                  : atingimentoDiaPercent >= 80
                  ? 'text-[#F5C542]'
                  : 'text-[#FF453A]'
              )}
            >
              {formatPercent(atingimentoDiaPercent)}
            </span>
            <span className="text-[10px] text-[#8A8A8A] block mt-1">
              Atingimento diário
            </span>
          </div>

          {/* Falta do Dia */}
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              Falta do Dia
            </span>
            <span className="text-xl font-black text-white block mt-0.5">
              {faltaDoDia > 0 ? formatCurrency(faltaDoDia) : 'R$ 0,00'}
            </span>
            <span className="text-[10px] text-[#8A8A8A] block mt-1">
              {faltaDoDia > 0 ? 'Para bater o dia' : 'Dia superado!'}
            </span>
          </div>

          {/* Número de Vendas */}
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              Número de Vendas
            </span>
            <span className="text-xl font-black text-white block mt-0.5">
              {formatNumber(vendasHoje)}
            </span>
            <span className="text-[10px] text-[#8A8A8A] block mt-1">
              cupons / atendimentos
            </span>
          </div>

          {/* Ticket Médio */}
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              Ticket Médio Hoje
            </span>
            <span className="text-xl font-black text-[#35C759] block mt-0.5">
              {formatCurrency(ticketHoje)}
            </span>
            <span className="text-[10px] text-[#8A8A8A] block mt-1">
              por atendimento
            </span>
          </div>

          {/* Lançamentos Computados */}
          <div className="p-3.5 rounded-xl bg-black/40 border border-white/[0.06]">
            <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
              Lançamentos Hoje
            </span>
            <span className="text-xl font-black text-white block mt-0.5">
              {todayEntries.length}
            </span>
            <span className="text-[10px] text-[#8A8A8A] block mt-1">
              registros no sistema
            </span>
          </div>
        </div>

        {/* Barra de Progresso do Dia */}
        <div>
          <ProgressBar
            current={realizadoHoje}
            target={metaDiaria}
            label="Atingimento da Meta de Hoje"
            sublabel={formatCurrency(realizadoHoje) + ' de ' + formatCurrency(metaDiaria)}
            size="md"
          />
        </div>

        {/* Comparativo Acumulado até Hoje (#33) */}
        <div className="p-4 rounded-xl bg-black/50 border border-white/[0.08]">
          <h5 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
            Posição Acumulada do Mês até Hoje
          </h5>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <span className="text-[#8A8A8A] block">Meta Acumulada:</span>
              <span className="font-bold text-white text-base">
                {formatCurrency(metaAcumuladaAteHoje)}
              </span>
            </div>
            <div>
              <span className="text-[#8A8A8A] block">Realizado Acumulado:</span>
              <span className="font-bold text-[#35C759] text-base">
                {formatCurrency(realizadoAcumuladoAteHoje)}
              </span>
            </div>
            <div>
              <span className="text-[#8A8A8A] block">Gap Geral:</span>
              <span
                className={clsx(
                  'font-bold text-base font-mono',
                  gapAcumulado >= 0 ? 'text-[#35C759]' : 'text-[#FF453A]'
                )}
              >
                {gapAcumulado >= 0 ? '+' : ''}{formatCurrency(gapAcumulado)}
              </span>
            </div>
          </div>
        </div>

        {/* Detalhamento dos Lançamentos de Hoje */}
        <div>
          <h5 className="text-xs font-bold text-[#8A8A8A] uppercase tracking-wider mb-2">
            Lançamentos Realizados Hoje ({formatDateBr(targetDate)})
          </h5>
          <div className="space-y-1.5 max-h-48 overflow-y-auto">
            {todayEntries.length === 0 ? (
              <p className="text-xs text-[#8A8A8A] italic">Nenhum lançamento registrado nesta data.</p>
            ) : (
              todayEntries.map((e) => (
                <div
                  key={e.id}
                  className="flex items-center justify-between p-2.5 rounded-lg bg-white/[0.02] border border-white/[0.04] text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#35C759]" />
                    <span className="font-bold text-white">{e.vendedor}</span>
                    <span className="text-[#8A8A8A]">({e.numVendas} vendas)</span>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-white">{formatCurrency(e.faturamento)}</span>
                    <span className="text-[10px] text-[#35C759] ml-2">Ticket: {formatCurrency(e.ticketMedio)}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
};
