import React, { useState } from 'react';
import {
  SellerPerformance,
  SaleEntry,
  Seller,
  SystemConfig,
} from '../../types';
import { formatCurrency, formatPercent, formatNumber } from '../../utils/formatters';
import { ProgressBar } from '../Common/ProgressBar';
import { Badge } from '../Common/Badge';
import { clsx } from 'clsx';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import {
  UserCheck,
  TrendingUp,
  Receipt,
  ShoppingBag,
  Award,
  ChevronRight,
  Filter,
  BarChart2,
  PieChart,
} from 'lucide-react';
import { calculateTicket } from '../../utils/calculations';

interface SellersDashboardProps {
  sellers: Seller[];
  performances: SellerPerformance[];
  entries: SaleEntry[];
  config: SystemConfig;
  onOpenNewEntry: () => void;
}

export const SellersDashboard: React.FC<SellersDashboardProps> = ({
  sellers,
  performances,
  entries,
  config,
  onOpenNewEntry,
}) => {
  const [selectedSeller, setSelectedSeller] = useState<string>('todos');

  // Filter sellers that are team salespeople (Alessandra, Felipe, Arnaldo)
  const teamPerformances = performances.filter(
    (p) => !p.nome.toLowerCase().includes('balcão') && !p.nome.toLowerCase().includes('loja')
  );

  const activeSellerPerf = teamPerformances.find(
    (p) => p.nome.toLowerCase() === selectedSeller.toLowerCase()
  );

  // Daily points for selected seller
  const getSellerDailyData = (sellerName: string) => {
    const sellerEntries = entries.filter(
      (e) => e.vendedor.toLowerCase() === sellerName.toLowerCase()
    );
    const diasOperacionais = config.diasOperacionais || 26;
    const diasDecorridos = config.diasDecorridos || 24;

    const data = [];
    let acumulado = 0;
    const metaLinear = ((config.metaEquipe || 155000) / 3) / diasOperacionais;

    for (let d = 1; d <= diasOperacionais; d++) {
      const dayEntries = sellerEntries.filter((e) => {
        let dia = 0;
        if (e.data.includes('-')) dia = parseInt(e.data.split('-')[2], 10);
        else if (e.data.includes('/')) dia = parseInt(e.data.split('/')[0], 10);
        return dia === d;
      });

      const faturamentoDia = dayEntries.reduce((acc, curr) => acc + curr.faturamento, 0);
      const vendasDia = dayEntries.reduce((acc, curr) => acc + curr.numVendas, 0);
      const ticketDia = calculateTicket(faturamentoDia, vendasDia);

      if (d <= diasDecorridos) {
        acumulado += faturamentoDia;
      }

      data.push({
        dia: `Dia ${d}`,
        diaNum: d,
        faturamento: d <= diasDecorridos ? faturamentoDia : null,
        acumulado: d <= diasDecorridos ? acumulado : null,
        metaLinear: Math.round(metaLinear * d),
        vendas: d <= diasDecorridos ? vendasDia : null,
        ticket: d <= diasDecorridos && vendasDia > 0 ? ticketDia : null,
      });
    }

    return data;
  };

  const sellerChartData = activeSellerPerf ? getSellerDailyData(activeSellerPerf.nome) : [];

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Top Filter Bar (#25) */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-[#35C759]" />
          <span className="text-xs font-semibold uppercase tracking-wider text-[#8A8A8A]">
            Filtro por Vendedor:
          </span>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={() => setSelectedSeller('todos')}
            className={clsx(
              'px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all',
              selectedSeller === 'todos'
                ? 'bg-[#35C759] text-black shadow-[0_0_12px_rgba(53,199,89,0.3)]'
                : 'bg-white/[0.04] text-[#8A8A8A] hover:text-white border border-white/[0.08]'
            )}
          >
            TODOS
          </button>
          {teamPerformances.map((p) => (
            <button
              key={p.nome}
              onClick={() => setSelectedSeller(p.nome)}
              className={clsx(
                'px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all',
                selectedSeller.toLowerCase() === p.nome.toLowerCase()
                  ? 'bg-[#35C759] text-black shadow-[0_0_12px_rgba(53,199,89,0.3)]'
                  : 'bg-white/[0.04] text-[#8A8A8A] hover:text-white border border-white/[0.08]'
              )}
            >
              {p.nome.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Section 24: Cards dos Vendedores */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {teamPerformances.map((perf) => {
          const isSelected = selectedSeller.toLowerCase() === perf.nome.toLowerCase();

          return (
            <div
              key={perf.nome}
              onClick={() => setSelectedSeller(perf.nome)}
              className={clsx(
                'relative rounded-2xl border bg-white/[0.03] backdrop-blur-md p-5 cursor-pointer transition-all hover:scale-[1.01] group',
                isSelected
                  ? 'border-[#35C759] shadow-[0_0_20px_rgba(53,199,89,0.15)] ring-1 ring-[#35C759]'
                  : 'border-white/[0.08] hover:border-white/20'
              )}
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-700 to-teal-500 flex items-center justify-center font-bold text-white text-sm shadow-sm">
                    {perf.nome.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-white tracking-tight">
                      {perf.nome}
                    </h4>
                    <p className="text-[11px] text-[#8A8A8A]">
                      Part. Equipe: {formatPercent(perf.participacaoEquipePercent)}
                    </p>
                  </div>
                </div>

                <Badge
                  variant={
                    perf.atingimentoPercent >= 100
                      ? 'positivo'
                      : perf.atingimentoPercent >= 85
                      ? 'alerta'
                      : 'negativo'
                  }
                  size="sm"
                >
                  {formatPercent(perf.atingimentoPercent)}
                </Badge>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="p-2.5 rounded-lg bg-black/40 border border-white/[0.04]">
                  <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
                    Faturamento
                  </span>
                  <span className="text-base font-bold text-white block mt-0.5">
                    {formatCurrency(perf.faturamento)}
                  </span>
                </div>

                <div className="p-2.5 rounded-lg bg-black/40 border border-white/[0.04]">
                  <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
                    Vendas
                  </span>
                  <span className="text-base font-bold text-white block mt-0.5">
                    {formatNumber(perf.numVendas)}
                  </span>
                </div>

                <div className="p-2.5 rounded-lg bg-black/40 border border-white/[0.04]">
                  <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
                    Ticket Médio
                  </span>
                  <span className="text-base font-bold text-[#35C759] block mt-0.5">
                    {formatCurrency(perf.ticketMedio)}
                  </span>
                </div>

                <div className="p-2.5 rounded-lg bg-black/40 border border-white/[0.04]">
                  <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">
                    Meta Ref. (1/3)
                  </span>
                  <span className="text-base font-bold text-white/80 block mt-0.5">
                    {formatCurrency(perf.metaReferencia)}
                  </span>
                </div>
              </div>

              {/* Progress Bar */}
              <ProgressBar
                current={perf.faturamento}
                target={perf.metaReferencia}
                size="sm"
                showPercent={false}
              />

              <div className="mt-3 flex items-center justify-between text-xs text-[#8A8A8A]">
                <span>
                  {perf.falta > 0
                    ? `Falta ${formatCurrency(perf.falta)}`
                    : 'Meta batida! 🎉'}
                </span>
                <span className="text-[#35C759] font-medium flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform">
                  Ver detalhes <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Sections 26 & 27: Detalhamento Individual do Vendedor Selecionado */}
      {activeSellerPerf && (
        <div className="space-y-6 pt-2">
          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-white/[0.08]">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center font-black text-white text-xl shadow-[0_0_20px_rgba(53,199,89,0.3)]">
                  {activeSellerPerf.nome.charAt(0)}
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#35C759]">
                    Painel Individual de Desempenho
                  </span>
                  <h3 className="text-2xl font-black text-white tracking-tight">
                    {activeSellerPerf.nome}
                  </h3>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedSeller('todos')}
                  className="px-3 py-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] text-xs font-semibold text-[#8A8A8A] hover:text-white border border-white/[0.08] transition-colors"
                >
                  Fechar Detalhes
                </button>
              </div>
            </div>

            {/* Section 26: Indicadores Detalhados */}
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 mb-6">
              <div className="p-3 rounded-xl bg-black/40 border border-white/[0.06]">
                <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">Faturamento</span>
                <span className="text-base font-extrabold text-white block mt-1">{formatCurrency(activeSellerPerf.faturamento)}</span>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/[0.06]">
                <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">Meta Ref.</span>
                <span className="text-base font-extrabold text-white/80 block mt-1">{formatCurrency(activeSellerPerf.metaReferencia)}</span>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/[0.06]">
                <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">% da Meta</span>
                <span className="text-base font-extrabold text-[#35C759] block mt-1">{formatPercent(activeSellerPerf.atingimentoPercent)}</span>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/[0.06]">
                <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">Falta</span>
                <span className="text-base font-extrabold text-white block mt-1">{formatCurrency(activeSellerPerf.falta)}</span>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/[0.06]">
                <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">Nº de Vendas</span>
                <span className="text-base font-extrabold text-white block mt-1">{formatNumber(activeSellerPerf.numVendas)}</span>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/[0.06]">
                <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">Ticket Médio</span>
                <span className="text-base font-extrabold text-[#35C759] block mt-1">{formatCurrency(activeSellerPerf.ticketMedio)}</span>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/[0.06]">
                <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">Participação</span>
                <span className="text-base font-extrabold text-white block mt-1">{formatPercent(activeSellerPerf.participacaoEquipePercent)}</span>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/[0.06]">
                <span className="text-[10px] text-[#8A8A8A] uppercase font-semibold block">Média Diária</span>
                <span className="text-base font-extrabold text-white block mt-1">{formatCurrency(activeSellerPerf.mediaDiaria)}</span>
              </div>
            </div>

            {/* Section 27: Gráficos Individuais */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Gráfico 1: Faturamento Diário (Barras) */}
              <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                  Faturamento Diário (R$)
                </h4>
                <div className="h-56 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={sellerChartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                      <XAxis dataKey="dia" tick={{ fill: '#8A8A8A', fontSize: 10 }} tickLine={false} />
                      <YAxis tick={{ fill: '#8A8A8A', fontSize: 10 }} tickLine={false} width={50} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#121212', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px' }}
                        formatter={(val: any) => formatCurrency(Number(val))}
                      />
                      <Bar dataKey="faturamento" name="Faturamento (R$)" fill="#35C759" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Gráfico 2: Faturamento Acumulado (Linha) */}
              <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                  Faturamento Acumulado vs Meta de Referência
                </h4>
                <div className="h-56 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={sellerChartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                      <XAxis dataKey="dia" tick={{ fill: '#8A8A8A', fontSize: 10 }} tickLine={false} />
                      <YAxis tick={{ fill: '#8A8A8A', fontSize: 10 }} tickLine={false} width={50} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#121212', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px' }}
                        formatter={(val: any) => formatCurrency(Number(val))}
                      />
                      <Line type="monotone" dataKey="metaLinear" name="Meta Ref. Acumulada" stroke="rgba(255,255,255,0.3)" strokeDasharray="3 3" dot={false} />
                      <Line type="monotone" dataKey="acumulado" name="Realizado Acumulado" stroke="#35C759" strokeWidth={2.5} dot={{ r: 2 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Gráfico 3: Ticket Médio Diário (Linha) */}
              <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                  Evolução do Ticket Médio (R$)
                </h4>
                <div className="h-56 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={sellerChartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                      <XAxis dataKey="dia" tick={{ fill: '#8A8A8A', fontSize: 10 }} tickLine={false} />
                      <YAxis tick={{ fill: '#8A8A8A', fontSize: 10 }} tickLine={false} width={45} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#121212', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px' }}
                        formatter={(val: any) => formatCurrency(Number(val))}
                      />
                      <Line type="monotone" dataKey="ticket" name="Ticket Médio" stroke="#F5C542" strokeWidth={2} dot={{ r: 3 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Gráfico 4: Número de Vendas Diário (Barras) */}
              <div className="p-4 rounded-xl bg-black/40 border border-white/[0.06]">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
                  Volume de Vendas Diárias
                </h4>
                <div className="h-56 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={sellerChartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                      <XAxis dataKey="dia" tick={{ fill: '#8A8A8A', fontSize: 10 }} tickLine={false} />
                      <YAxis tick={{ fill: '#8A8A8A', fontSize: 10 }} tickLine={false} width={40} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#121212', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px' }}
                      />
                      <Bar dataKey="vendas" name="Vendas Concluídas" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Section 28: Comparação Individual (Visão Gerencial Construtiva) */}
      <div className="rounded-2xl border border-white/[0.08] bg-white/[0.03] backdrop-blur-md p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-white tracking-tight">
              Matriz Comparativa da Equipe
            </h3>
            <p className="text-xs text-[#8A8A8A]">
              Análise construtiva para alinhamento de oportunidades e desenvolvimento contínuo
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/[0.08] text-[#8A8A8A] font-semibold uppercase tracking-wider">
                <th className="py-3 px-3">Vendedor</th>
                <th className="py-3 px-3">Faturamento</th>
                <th className="py-3 px-3">Vendas</th>
                <th className="py-3 px-3">Ticket Médio</th>
                <th className="py-3 px-3">Part. Equipe</th>
                <th className="py-3 px-3">% Meta Ref.</th>
                <th className="py-3 px-3">Média Diária</th>
                <th className="py-3 px-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {teamPerformances.map((perf) => (
                <tr
                  key={perf.nome}
                  className="hover:bg-white/[0.02] transition-colors cursor-pointer"
                  onClick={() => setSelectedSeller(perf.nome)}
                >
                  <td className="py-3.5 px-3 font-bold text-white flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#35C759]" />
                    {perf.nome}
                  </td>
                  <td className="py-3.5 px-3 font-semibold text-white">
                    {formatCurrency(perf.faturamento)}
                  </td>
                  <td className="py-3.5 px-3 text-[#8A8A8A]">
                    {formatNumber(perf.numVendas)}
                  </td>
                  <td className="py-3.5 px-3 font-semibold text-[#35C759]">
                    {formatCurrency(perf.ticketMedio)}
                  </td>
                  <td className="py-3.5 px-3 text-white/90">
                    {formatPercent(perf.participacaoEquipePercent)}
                  </td>
                  <td className="py-3.5 px-3 font-bold text-white">
                    {formatPercent(perf.atingimentoPercent)}
                  </td>
                  <td className="py-3.5 px-3 text-[#8A8A8A]">
                    {formatCurrency(perf.mediaDiaria)}/dia
                  </td>
                  <td className="py-3.5 px-3">
                    <Badge
                      variant={
                        perf.atingimentoPercent >= 100
                          ? 'positivo'
                          : perf.atingimentoPercent >= 85
                          ? 'alerta'
                          : 'negativo'
                      }
                      size="sm"
                    >
                      {perf.atingimentoPercent >= 100
                        ? 'Superando'
                        : perf.atingimentoPercent >= 85
                        ? 'Evoluindo'
                        : 'Atenção'}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
