import {
  SaleEntry,
  SystemConfig,
  TeamKpis,
  StoreKpis,
  SellerPerformance,
  WeeklyBreakdown,
  SmartAlert,
  Seller,
} from '../types';

export function calculateTicket(faturamento: number, numVendas: number): number {
  if (!numVendas || numVendas <= 0) return 0;
  return Number((faturamento / numVendas).toFixed(2));
}

export function computeStoreKpis(
  entries: SaleEntry[],
  config: SystemConfig
): StoreKpis {
  const realizado = entries.reduce((acc, curr) => acc + (curr.faturamento || 0), 0);
  const numVendas = entries.reduce((acc, curr) => acc + (curr.numVendas || 0), 0);
  const ticketMedio = calculateTicket(realizado, numVendas);

  const meta = config.metaLoja || 400000;
  const mediaHistorica = config.mediaHistoricaLoja || 354000;
  const atingimentoPercent = meta > 0 ? (realizado / meta) * 100 : 0;
  const falta = Math.max(0, meta - realizado);
  const faltaPercent = meta > 0 ? Math.max(0, 100 - atingimentoPercent) : 0;

  // Remuneração do gestor (2% sobre o que ultrapassa a média histórica)
  const excedenteMedia = Math.max(0, realizado - mediaHistorica);
  const percentualRemuneracao = (config.percentualRemuneracaoLoja || 2) / 100;
  const remuneracaoGestor = excedenteMedia * percentualRemuneracao;

  // Ritmo e projeções
  const diasOperacionais = Math.max(1, config.diasOperacionais || 26);
  // Calcula dias decorridos com base no config ou nos lançamentos
  const diasDecorridos = Math.max(1, Math.min(config.diasDecorridos || 24, diasOperacionais));
  const diasRestantes = Math.max(1, diasOperacionais - diasDecorridos);

  const ritmoAtual = realizado / diasDecorridos;
  const ritmoNecessario = falta / diasRestantes;
  const projecao = ritmoAtual * diasOperacionais;

  const excedenteProjetado = Math.max(0, projecao - mediaHistorica);
  const remuneracaoProjetada = excedenteProjetado * percentualRemuneracao;

  const metaDiariaIdeal = meta / diasOperacionais;
  let statusRitmo: 'positivo' | 'alerta' | 'negativo' = 'positivo';
  if (ritmoAtual >= metaDiariaIdeal) {
    statusRitmo = 'positivo';
  } else if (ritmoAtual >= metaDiariaIdeal * 0.88) {
    statusRitmo = 'alerta';
  } else {
    statusRitmo = 'negativo';
  }

  return {
    meta,
    mediaHistorica,
    realizado,
    atingimentoPercent,
    falta,
    faltaPercent,
    excedenteMedia,
    remuneracaoGestor,
    remuneracaoProjetada,
    numVendas,
    ticketMedio,
    ritmoAtual,
    ritmoNecessario,
    projecao,
    statusRitmo,
    diasOperacionais,
    diasDecorridos,
    diasRestantes,
  };
}

export function computeTeamKpis(
  entries: SaleEntry[],
  config: SystemConfig,
  activeSellersCount: number = 3
): TeamKpis {
  const realizado = entries.reduce((acc, curr) => acc + (curr.faturamento || 0), 0);
  const numVendas = entries.reduce((acc, curr) => acc + (curr.numVendas || 0), 0);
  const ticketMedio = calculateTicket(realizado, numVendas);

  const meta = config.metaEquipe || 155000;
  const atingimentoPercent = meta > 0 ? (realizado / meta) * 100 : 0;
  const falta = Math.max(0, meta - realizado);
  const faltaPercent = meta > 0 ? Math.max(0, 100 - atingimentoPercent) : 0;

  const diasOperacionais = Math.max(1, config.diasOperacionais || 26);
  const diasDecorridos = Math.max(1, Math.min(config.diasDecorridos || 24, diasOperacionais));
  const diasRestantes = Math.max(1, diasOperacionais - diasDecorridos);

  const ritmoAtual = realizado / diasDecorridos;
  const ritmoNecessario = falta / diasRestantes;
  const projecao = ritmoAtual * diasOperacionais;

  const metaDiariaIdeal = meta / diasOperacionais;
  let statusRitmo: 'positivo' | 'alerta' | 'negativo' = 'positivo';
  if (ritmoAtual >= metaDiariaIdeal) {
    statusRitmo = 'positivo';
  } else if (ritmoAtual >= metaDiariaIdeal * 0.88) {
    statusRitmo = 'alerta';
  } else {
    statusRitmo = 'negativo';
  }

  // Pontos da equipe (Acima de R$ 155.000: a cada 10% -> 100 pontos = R$ 100)
  const percentualIncremento = config.percentualIncrementoPontos || 10;
  const pontosPorInc = config.pontosPorIncremento || 100;
  const valorPonto = config.valorPorPonto || 1;

  let pontos = 0;
  let proximoNivelMeta = meta;

  if (realizado >= meta) {
    const valorAcima = realizado - meta;
    const valorDegrau = meta * (percentualIncremento / 100);
    const degraus = Math.floor(valorAcima / valorDegrau);
    pontos = degraus * pontosPorInc;
    proximoNivelMeta = meta + (degraus + 1) * valorDegrau;
  } else {
    proximoNivelMeta = meta; // primeiro nível é a própria meta
  }

  const valorPontos = pontos * valorPonto;
  const faltaProximoNivel = Math.max(0, proximoNivelMeta - realizado);

  // Bônus coletivo: se bateu R$ 155.000, cada um ganha R$ 200
  const bonusElegivel = realizado >= meta;
  const bonusTotal = bonusElegivel ? (config.bonusPorVendedor || 200) * activeSellersCount : 0;

  return {
    meta,
    realizado,
    atingimentoPercent,
    falta,
    faltaPercent,
    numVendas,
    ticketMedio,
    ritmoAtual,
    ritmoNecessario,
    projecao,
    statusRitmo,
    pontos,
    valorPontos,
    proximoNivelMeta,
    faltaProximoNivel,
    bonusElegivel,
    bonusTotal,
  };
}

export function computeSellerPerformances(
  entries: SaleEntry[],
  sellers: Seller[],
  config: SystemConfig
): SellerPerformance[] {
  const activeSellers = sellers.filter((s) => s.ativo);
  const totalEquipe = entries.reduce((acc, curr) => acc + (curr.faturamento || 0), 0);
  const metaIndividualReferencia = (config.metaEquipe || 155000) / (activeSellers.length || 1);
  const diasDecorridos = Math.max(1, config.diasDecorridos || 24);

  return activeSellers.map((seller) => {
    const sellerEntries = entries.filter((e) => e.vendedor.toLowerCase() === seller.nome.toLowerCase());
    const faturamento = sellerEntries.reduce((acc, curr) => acc + (curr.faturamento || 0), 0);
    const numVendas = sellerEntries.reduce((acc, curr) => acc + (curr.numVendas || 0), 0);
    const ticketMedio = calculateTicket(faturamento, numVendas);

    const participacaoEquipePercent = totalEquipe > 0 ? (faturamento / totalEquipe) * 100 : 0;
    const metaReferencia = metaIndividualReferencia;
    const atingimentoPercent = metaReferencia > 0 ? (faturamento / metaReferencia) * 100 : 0;
    const falta = Math.max(0, metaReferencia - faturamento);
    const mediaDiaria = faturamento / diasDecorridos;

    let status: 'positivo' | 'alerta' | 'negativo' = 'positivo';
    if (atingimentoPercent >= 100) {
      status = 'positivo';
    } else if (atingimentoPercent >= 85) {
      status = 'alerta';
    } else {
      status = 'negativo';
    }

    return {
      nome: seller.nome,
      faturamento,
      numVendas,
      ticketMedio,
      participacaoEquipePercent,
      metaReferencia,
      atingimentoPercent,
      falta,
      mediaDiaria,
      status,
    };
  });
}

export function computeWeeklyBreakdown(
  entries: SaleEntry[],
  config: SystemConfig,
  type: 'loja' | 'equipe' = 'loja'
): WeeklyBreakdown[] {
  const metaTotal = type === 'loja' ? (config.metaLoja || 400000) : (config.metaEquipe || 155000);
  
  // Dividimos 31 dias em 5 semanas: 
  // Sem 1: dias 1-7 (7d)
  // Sem 2: dias 8-14 (7d)
  // Sem 3: dias 15-21 (7d)
  // Sem 4: dias 22-28 (7d)
  // Sem 5: dias 29-31 (3d)
  const weekDefinitions = [
    { semana: 1, label: 'Semana 1', diasPeriodo: 'Dias 01 a 07', startDay: 1, endDay: 7, daysCount: 7 },
    { semana: 2, label: 'Semana 2', diasPeriodo: 'Dias 08 a 14', startDay: 8, endDay: 14, daysCount: 7 },
    { semana: 3, label: 'Semana 3', diasPeriodo: 'Dias 15 a 21', startDay: 15, endDay: 21, daysCount: 7 },
    { semana: 4, label: 'Semana 4', diasPeriodo: 'Dias 22 a 28', startDay: 22, endDay: 28, daysCount: 7 },
    { semana: 5, label: 'Semana 5', diasPeriodo: 'Dias 29 a 31', startDay: 29, endDay: 31, daysCount: 3 },
  ];

  const totalDays = 31;

  return weekDefinitions.map((w) => {
    // Meta proporcional aos dias da semana
    const metaSemana = (metaTotal / totalDays) * w.daysCount;

    // Filtra lançamentos dentro do período de dias
    const realizadoSemana = entries.reduce((acc, curr) => {
      let day = 0;
      if (curr.data.includes('-')) {
        const parts = curr.data.split('-');
        day = parseInt(parts[2], 10);
      } else if (curr.data.includes('/')) {
        const parts = curr.data.split('/');
        day = parseInt(parts[0], 10);
      }
      if (day >= w.startDay && day <= w.endDay) {
        return acc + (curr.faturamento || 0);
      }
      return acc;
    }, 0);

    const atingimentoPercent = metaSemana > 0 ? (realizadoSemana / metaSemana) * 100 : 0;
    const gap = realizadoSemana - metaSemana;

    let status: 'atingido' | 'atencao' | 'critico' = 'atingido';
    if (atingimentoPercent >= 100) {
      status = 'atingido';
    } else if (atingimentoPercent >= 85) {
      status = 'atencao';
    } else {
      status = 'critico';
    }

    return {
      semana: w.semana,
      label: w.label,
      diasPeriodo: w.diasPeriodo,
      meta: metaSemana,
      realizado: realizadoSemana,
      gap,
      atingimentoPercent,
      status,
    };
  });
}

export function computeDailyAccumulated(
  entries: SaleEntry[],
  config: SystemConfig,
  type: 'loja' | 'equipe' = 'loja'
) {
  const metaTotal = type === 'loja' ? (config.metaLoja || 400000) : (config.metaEquipe || 155000);
  const diasOperacionais = config.diasOperacionais || 26;
  const diasDecorridos = config.diasDecorridos || 24;

  const data = [];
  let acumulado = 0;
  const metaDiariaLinear = metaTotal / diasOperacionais;

  for (let dia = 1; dia <= diasOperacionais; dia++) {
    // Soma lançamentos deste dia
    const faturamentoDia = entries.reduce((acc, curr) => {
      let d = 0;
      if (curr.data.includes('-')) {
        d = parseInt(curr.data.split('-')[2], 10);
      } else if (curr.data.includes('/')) {
        d = parseInt(curr.data.split('/')[0], 10);
      }
      if (d === dia) {
        return acc + (curr.faturamento || 0);
      }
      return acc;
    }, 0);

    if (dia <= diasDecorridos) {
      acumulado += faturamentoDia;
    }

    const metaAcumulada = metaDiariaLinear * dia;

    data.push({
      dia: `Dia ${dia}`,
      diaNum: dia,
      metaDiaria: Math.round(metaDiariaLinear),
      metaAcumulada: Math.round(metaAcumulada),
      realizadoDia: dia <= diasDecorridos ? Math.round(faturamentoDia) : null,
      realizadoAcumulado: dia <= diasDecorridos ? Math.round(acumulado) : null,
      isFuture: dia > diasDecorridos,
      gap: dia <= diasDecorridos ? Math.round(acumulado - metaAcumulada) : null,
    });
  }

  return data;
}

export function generateSmartAlerts(
  storeKpis: StoreKpis,
  teamKpis: TeamKpis,
  weekly: WeeklyBreakdown[]
): SmartAlert[] {
  const alerts: SmartAlert[] = [];

  // 1. Alerta de ritmo da equipe
  if (teamKpis.statusRitmo === 'positivo') {
    alerts.push({
      id: 'ritmo-equipe-pos',
      tipo: 'positivo',
      categoria: 'equipe',
      titulo: 'Ritmo da Equipe Positivo',
      mensagem: `A equipe está vendendo R$ ${Math.round(teamKpis.ritmoAtual).toLocaleString('pt-BR')}/dia, acima do ritmo diário necessário (R$ ${Math.round(teamKpis.ritmoNecessario).toLocaleString('pt-BR')}/dia). Projeção: R$ ${Math.round(teamKpis.projecao).toLocaleString('pt-BR')}.`,
    });
  } else {
    alerts.push({
      id: 'ritmo-equipe-neg',
      tipo: 'negativo',
      categoria: 'equipe',
      titulo: 'Atenção ao Ritmo da Equipe',
      mensagem: `Faturamento da equipe está abaixo do ritmo necessário. Necessário acelerar para R$ ${Math.round(teamKpis.ritmoNecessario).toLocaleString('pt-BR')}/dia nos ${storeKpis.diasRestantes} dias restantes.`,
    });
  }

  // 2. Alerta de bônus / pontos
  if (teamKpis.bonusElegivel) {
    alerts.push({
      id: 'bonus-batido',
      tipo: 'positivo',
      categoria: 'equipe',
      titulo: 'Meta da Equipe Atingida!',
      mensagem: `Parabéns! Meta de R$ 155.000 batida! Bônus de R$ 600 desbloqueado. Pontos acumulados: ${teamKpis.pontos} pts (≈ R$ ${teamKpis.valorPontos.toLocaleString('pt-BR')}). Falta R$ ${Math.round(teamKpis.faltaProximoNivel).toLocaleString('pt-BR')} para o próximo nível.`,
    });
  } else if (teamKpis.falta <= 20000) {
    alerts.push({
      id: 'bonus-proximo',
      tipo: 'alerta',
      categoria: 'equipe',
      titulo: 'Meta de R$ 155k Muito Próxima!',
      mensagem: `Faltam apenas R$ ${Math.round(teamKpis.falta).toLocaleString('pt-BR')} para a equipe desbloquear o bônus coletivo de R$ 600 (R$ 200 por vendedor).`,
    });
  }

  // 3. Alerta da semana atual
  const semanaAtual = weekly.find((w) => w.atingimentoPercent < 100 && w.realizado > 0) || weekly[3];
  if (semanaAtual) {
    const faltaSemana = Math.max(0, semanaAtual.meta - semanaAtual.realizado);
    if (faltaSemana > 0) {
      alerts.push({
        id: 'semana-alerta',
        tipo: 'alerta',
        categoria: 'loja',
        titulo: `Meta da ${semanaAtual.label}`,
        mensagem: `Faltam R$ ${Math.round(faltaSemana).toLocaleString('pt-BR')} para atingir a meta da ${semanaAtual.label} (${semanaAtual.diasPeriodo}).`,
      });
    }
  }

  // 4. Remuneração da Loja (Guilherme)
  if (storeKpis.realizado > storeKpis.mediaHistorica) {
    alerts.push({
      id: 'remuneracao-gestor',
      tipo: 'positivo',
      categoria: 'loja',
      titulo: 'Excedente da Média Histórica Atingido',
      mensagem: `Loja ultrapassou a média histórica de R$ ${storeKpis.mediaHistorica.toLocaleString('pt-BR')}. Excedente atual: R$ ${Math.round(storeKpis.excedenteMedia).toLocaleString('pt-BR')} gerando R$ ${storeKpis.remuneracaoGestor.toFixed(2).replace('.', ',')} de remuneração variável.`,
    });
  }

  return alerts;
}
