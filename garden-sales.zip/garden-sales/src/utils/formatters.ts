/**
 * Utilitários de formatação de moeda, números, datas e percentuais.
 * Padrão brasileiro estrito (pt-BR) conforme requisitos do projeto.
 */

export function formatCurrency(value: number | null | undefined): string {
  if (value === null || value === undefined || isNaN(value)) {
    return 'R$ 0,00';
  }
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}

export function formatCompactCurrency(value: number | null | undefined): string {
  if (value === null || value === undefined || isNaN(value)) {
    return 'R$ 0';
  }
  if (Math.abs(value) >= 1_000_000) {
    return `R$ ${(value / 1_000_000).toFixed(1).replace('.', ',')}M`;
  }
  if (Math.abs(value) >= 1_000) {
    return `R$ ${(value / 1_000).toFixed(1).replace('.', ',')}k`;
  }
  return formatCurrency(value);
}

export function formatPercent(value: number | null | undefined, decimals = 1): string {
  if (value === null || value === undefined || isNaN(value)) {
    return '0,0%';
  }
  return `${value.toFixed(decimals).replace('.', ',')}%`;
}

export function formatNumber(value: number | null | undefined): string {
  if (value === null || value === undefined || isNaN(value)) {
    return '0';
  }
  return new Intl.NumberFormat('pt-BR').format(Math.round(value));
}

export function formatDateBr(dateStr: string | null | undefined): string {
  if (!dateStr) return '--/--/----';
  // Handles YYYY-MM-DD or ISO
  if (dateStr.includes('-')) {
    const parts = dateStr.split('T')[0].split('-');
    if (parts.length === 3) {
      return `${parts[2].padStart(2, '0')}/${parts[1].padStart(2, '0')}/${parts[0]}`;
    }
  }
  return dateStr;
}

export function parseCurrencyInput(raw: string): number {
  if (!raw) return 0;
  // Remove R$, spaces, dots, replace comma with dot
  const clean = raw.replace(/[^\d,-]/g, '').replace(',', '.');
  const parsed = parseFloat(clean);
  return isNaN(parsed) ? 0 : parsed;
}

export function getStatusColor(status: 'positivo' | 'alerta' | 'negativo'): {
  text: string;
  bg: string;
  border: string;
  glow: string;
  badge: string;
} {
  switch (status) {
    case 'positivo':
      return {
        text: 'text-[#35C759]',
        bg: 'bg-[#35C759]/10',
        border: 'border-[#35C759]/30',
        glow: 'shadow-[0_0_15px_rgba(53,199,89,0.25)]',
        badge: 'bg-[#35C759]/15 text-[#35C759] border-[#35C759]/30',
      };
    case 'alerta':
      return {
        text: 'text-[#F5C542]',
        bg: 'bg-[#F5C542]/10',
        border: 'border-[#F5C542]/30',
        glow: 'shadow-[0_0_15px_rgba(245,197,66,0.25)]',
        badge: 'bg-[#F5C542]/15 text-[#F5C542] border-[#F5C542]/30',
      };
    case 'negativo':
    default:
      return {
        text: 'text-[#FF453A]',
        bg: 'bg-[#FF453A]/10',
        border: 'border-[#FF453A]/30',
        glow: 'shadow-[0_0_15px_rgba(255,69,58,0.25)]',
        badge: 'bg-[#FF453A]/15 text-[#FF453A] border-[#FF453A]/30',
      };
  }
}
