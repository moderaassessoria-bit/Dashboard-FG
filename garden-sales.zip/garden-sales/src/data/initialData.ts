import { SaleEntry, Seller, SystemConfig } from '../types';

export const INITIAL_SELLERS: Seller[] = [
  { id: '1', nome: 'Alessandra', ativo: true, cor: '#35C759' },
  { id: '2', nome: 'Felipe', ativo: true, cor: '#3B82F6' },
  { id: '3', nome: 'Arnaldo', ativo: true, cor: '#F5C542' },
  { id: '4', nome: 'Loja / Balcão Central', ativo: true, cor: '#A855F7' },
];

export const INITIAL_CONFIG: SystemConfig = {
  // Loja
  metaLoja: 400000,
  mediaHistoricaLoja: 354000,
  percentualRemuneracaoLoja: 2.0,

  // Equipe
  metaEquipe: 155000,
  mediaHistoricaEquipe: 140000,
  bonusPorVendedor: 200,

  // Pontos
  percentualIncrementoPontos: 10,
  pontosPorIncremento: 100,
  valorPorPonto: 1,

  // Operacional
  mesReferencia: '2026-09',
  nomeMesReferencia: 'Setembro 2026',
  diasOperacionais: 26,
  diasDecorridos: 24,

  // Google Sheets
  googleSheetsUrl: '',
  googleSheetsConnected: false,
  ultimaSincronizacao: '24/09/2026 14:35',
};

// Gera dados realistas para o mês de referência até dia 24/09/2026
export const INITIAL_ENTRIES: SaleEntry[] = [
  // Semana 1 (Dias 1 a 7)
  { id: 'e-01', data: '2026-09-01', vendedor: 'Alessandra', faturamento: 2350.00, numVendas: 19, ticketMedio: 123.68, createdAt: '2026-09-01T18:00:00Z', origem: 'demo' },
  { id: 'e-02', data: '2026-09-01', vendedor: 'Felipe', faturamento: 2180.00, numVendas: 17, ticketMedio: 128.24, createdAt: '2026-09-01T18:00:00Z', origem: 'demo' },
  { id: 'e-03', data: '2026-09-01', vendedor: 'Arnaldo', faturamento: 2420.00, numVendas: 20, ticketMedio: 121.00, createdAt: '2026-09-01T18:00:00Z', origem: 'demo' },
  { id: 'e-04', data: '2026-09-01', vendedor: 'Loja / Balcão Central', faturamento: 8400.00, numVendas: 95, ticketMedio: 88.42, createdAt: '2026-09-01T18:00:00Z', origem: 'demo' },

  { id: 'e-05', data: '2026-09-02', vendedor: 'Alessandra', faturamento: 2640.00, numVendas: 21, ticketMedio: 125.71, createdAt: '2026-09-02T18:00:00Z', origem: 'demo' },
  { id: 'e-06', data: '2026-09-02', vendedor: 'Felipe', faturamento: 2490.00, numVendas: 18, ticketMedio: 138.33, createdAt: '2026-09-02T18:00:00Z', origem: 'demo' },
  { id: 'e-07', data: '2026-09-02', vendedor: 'Arnaldo', faturamento: 2310.00, numVendas: 19, ticketMedio: 121.58, createdAt: '2026-09-02T18:00:00Z', origem: 'demo' },
  { id: 'e-08', data: '2026-09-02', vendedor: 'Loja / Balcão Central', faturamento: 7900.00, numVendas: 88, ticketMedio: 89.77, createdAt: '2026-09-02T18:00:00Z', origem: 'demo' },

  { id: 'e-09', data: '2026-09-03', vendedor: 'Alessandra', faturamento: 2150.00, numVendas: 16, ticketMedio: 134.38, createdAt: '2026-09-03T18:00:00Z', origem: 'demo' },
  { id: 'e-10', data: '2026-09-03', vendedor: 'Felipe', faturamento: 2300.00, numVendas: 19, ticketMedio: 121.05, createdAt: '2026-09-03T18:00:00Z', origem: 'demo' },
  { id: 'e-11', data: '2026-09-03', vendedor: 'Arnaldo', faturamento: 2650.00, numVendas: 21, ticketMedio: 126.19, createdAt: '2026-09-03T18:00:00Z', origem: 'demo' },
  { id: 'e-12', data: '2026-09-03', vendedor: 'Loja / Balcão Central', faturamento: 8200.00, numVendas: 90, ticketMedio: 91.11, createdAt: '2026-09-03T18:00:00Z', origem: 'demo' },

  { id: 'e-13', data: '2026-09-04', vendedor: 'Alessandra', faturamento: 2890.00, numVendas: 23, ticketMedio: 125.65, createdAt: '2026-09-04T18:00:00Z', origem: 'demo' },
  { id: 'e-14', data: '2026-09-04', vendedor: 'Felipe', faturamento: 2600.00, numVendas: 20, ticketMedio: 130.00, createdAt: '2026-09-04T18:00:00Z', origem: 'demo' },
  { id: 'e-15', data: '2026-09-04', vendedor: 'Arnaldo', faturamento: 2750.00, numVendas: 22, ticketMedio: 125.00, createdAt: '2026-09-04T18:00:00Z', origem: 'demo' },
  { id: 'e-16', data: '2026-09-04', vendedor: 'Loja / Balcão Central', faturamento: 9100.00, numVendas: 104, ticketMedio: 87.50, createdAt: '2026-09-04T18:00:00Z', origem: 'demo' },

  { id: 'e-17', data: '2026-09-05', vendedor: 'Alessandra', faturamento: 3400.00, numVendas: 26, ticketMedio: 130.77, createdAt: '2026-09-05T18:00:00Z', origem: 'demo' },
  { id: 'e-18', data: '2026-09-05', vendedor: 'Felipe', faturamento: 3200.00, numVendas: 24, ticketMedio: 133.33, createdAt: '2026-09-05T18:00:00Z', origem: 'demo' },
  { id: 'e-19', data: '2026-09-05', vendedor: 'Arnaldo', faturamento: 3350.00, numVendas: 25, ticketMedio: 134.00, createdAt: '2026-09-05T18:00:00Z', origem: 'demo' },
  { id: 'e-20', data: '2026-09-05', vendedor: 'Loja / Balcão Central', faturamento: 11500.00, numVendas: 130, ticketMedio: 88.46, createdAt: '2026-09-05T18:00:00Z', origem: 'demo' },

  // Semana 2 (Dias 8 a 14)
  { id: 'e-21', data: '2026-09-08', vendedor: 'Alessandra', faturamento: 2450.00, numVendas: 19, ticketMedio: 128.95, createdAt: '2026-09-08T18:00:00Z', origem: 'demo' },
  { id: 'e-22', data: '2026-09-08', vendedor: 'Felipe', faturamento: 2350.00, numVendas: 18, ticketMedio: 130.56, createdAt: '2026-09-08T18:00:00Z', origem: 'demo' },
  { id: 'e-23', data: '2026-09-08', vendedor: 'Arnaldo', faturamento: 2500.00, numVendas: 20, ticketMedio: 125.00, createdAt: '2026-09-08T18:00:00Z', origem: 'demo' },
  { id: 'e-24', data: '2026-09-08', vendedor: 'Loja / Balcão Central', faturamento: 8600.00, numVendas: 98, ticketMedio: 87.76, createdAt: '2026-09-08T18:00:00Z', origem: 'demo' },

  { id: 'e-25', data: '2026-09-10', vendedor: 'Alessandra', faturamento: 2780.00, numVendas: 22, ticketMedio: 126.36, createdAt: '2026-09-10T18:00:00Z', origem: 'demo' },
  { id: 'e-26', data: '2026-09-10', vendedor: 'Felipe', faturamento: 2540.00, numVendas: 20, ticketMedio: 127.00, createdAt: '2026-09-10T18:00:00Z', origem: 'demo' },
  { id: 'e-27', data: '2026-09-10', vendedor: 'Arnaldo', faturamento: 2820.00, numVendas: 22, ticketMedio: 128.18, createdAt: '2026-09-10T18:00:00Z', origem: 'demo' },
  { id: 'e-28', data: '2026-09-10', vendedor: 'Loja / Balcão Central', faturamento: 8900.00, numVendas: 102, ticketMedio: 87.25, createdAt: '2026-09-10T18:00:00Z', origem: 'demo' },

  { id: 'e-29', data: '2026-09-12', vendedor: 'Alessandra', faturamento: 3600.00, numVendas: 28, ticketMedio: 128.57, createdAt: '2026-09-12T18:00:00Z', origem: 'demo' },
  { id: 'e-30', data: '2026-09-12', vendedor: 'Felipe', faturamento: 3450.00, numVendas: 26, ticketMedio: 132.69, createdAt: '2026-09-12T18:00:00Z', origem: 'demo' },
  { id: 'e-31', data: '2026-09-12', vendedor: 'Arnaldo', faturamento: 3750.00, numVendas: 29, ticketMedio: 129.31, createdAt: '2026-09-12T18:00:00Z', origem: 'demo' },
  { id: 'e-32', data: '2026-09-12', vendedor: 'Loja / Balcão Central', faturamento: 12800.00, numVendas: 145, ticketMedio: 88.28, createdAt: '2026-09-12T18:00:00Z', origem: 'demo' },

  // Semana 3 (Dias 15 a 21)
  { id: 'e-33', data: '2026-09-15', vendedor: 'Alessandra', faturamento: 2600.00, numVendas: 20, ticketMedio: 130.00, createdAt: '2026-09-15T18:00:00Z', origem: 'demo' },
  { id: 'e-34', data: '2026-09-15', vendedor: 'Felipe', faturamento: 2450.00, numVendas: 19, ticketMedio: 128.95, createdAt: '2026-09-15T18:00:00Z', origem: 'demo' },
  { id: 'e-35', data: '2026-09-15', vendedor: 'Arnaldo', faturamento: 2700.00, numVendas: 21, ticketMedio: 128.57, createdAt: '2026-09-15T18:00:00Z', origem: 'demo' },
  { id: 'e-36', data: '2026-09-15', vendedor: 'Loja / Balcão Central', faturamento: 8800.00, numVendas: 100, ticketMedio: 88.00, createdAt: '2026-09-15T18:00:00Z', origem: 'demo' },

  { id: 'e-37', data: '2026-09-17', vendedor: 'Alessandra', faturamento: 2900.00, numVendas: 22, ticketMedio: 131.82, createdAt: '2026-09-17T18:00:00Z', origem: 'demo' },
  { id: 'e-38', data: '2026-09-17', vendedor: 'Felipe', faturamento: 2700.00, numVendas: 21, ticketMedio: 128.57, createdAt: '2026-09-17T18:00:00Z', origem: 'demo' },
  { id: 'e-39', data: '2026-09-17', vendedor: 'Arnaldo', faturamento: 3100.00, numVendas: 24, ticketMedio: 129.17, createdAt: '2026-09-17T18:00:00Z', origem: 'demo' },
  { id: 'e-40', data: '2026-09-17', vendedor: 'Loja / Balcão Central', faturamento: 9400.00, numVendas: 108, ticketMedio: 87.04, createdAt: '2026-09-17T18:00:00Z', origem: 'demo' },

  { id: 'e-41', data: '2026-09-19', vendedor: 'Alessandra', faturamento: 4100.00, numVendas: 31, ticketMedio: 132.26, createdAt: '2026-09-19T18:00:00Z', origem: 'demo' },
  { id: 'e-42', data: '2026-09-19', vendedor: 'Felipe', faturamento: 3800.00, numVendas: 29, ticketMedio: 131.03, createdAt: '2026-09-19T18:00:00Z', origem: 'demo' },
  { id: 'e-43', data: '2026-09-19', vendedor: 'Arnaldo', faturamento: 4200.00, numVendas: 32, ticketMedio: 131.25, createdAt: '2026-09-19T18:00:00Z', origem: 'demo' },
  { id: 'e-44', data: '2026-09-19', vendedor: 'Loja / Balcão Central', faturamento: 14200.00, numVendas: 160, ticketMedio: 88.75, createdAt: '2026-09-19T18:00:00Z', origem: 'demo' },

  // Semana 4 (Dias 22 a 24 - até o dia atual)
  { id: 'e-45', data: '2026-09-22', vendedor: 'Alessandra', faturamento: 2850.00, numVendas: 22, ticketMedio: 129.55, createdAt: '2026-09-22T18:00:00Z', origem: 'demo' },
  { id: 'e-46', data: '2026-09-22', vendedor: 'Felipe', faturamento: 2650.00, numVendas: 20, ticketMedio: 132.50, createdAt: '2026-09-22T18:00:00Z', origem: 'demo' },
  { id: 'e-47', data: '2026-09-22', vendedor: 'Arnaldo', faturamento: 2980.00, numVendas: 23, ticketMedio: 129.57, createdAt: '2026-09-22T18:00:00Z', origem: 'demo' },
  { id: 'e-48', data: '2026-09-22', vendedor: 'Loja / Balcão Central', faturamento: 9700.00, numVendas: 110, ticketMedio: 88.18, createdAt: '2026-09-22T18:00:00Z', origem: 'demo' },

  { id: 'e-49', data: '2026-09-23', vendedor: 'Alessandra', faturamento: 3100.00, numVendas: 24, ticketMedio: 129.17, createdAt: '2026-09-23T18:00:00Z', origem: 'demo' },
  { id: 'e-50', data: '2026-09-23', vendedor: 'Felipe', faturamento: 2850.00, numVendas: 22, ticketMedio: 129.55, createdAt: '2026-09-23T18:00:00Z', origem: 'demo' },
  { id: 'e-51', data: '2026-09-23', vendedor: 'Arnaldo', faturamento: 3200.00, numVendas: 24, ticketMedio: 133.33, createdAt: '2026-09-23T18:00:00Z', origem: 'demo' },
  { id: 'e-52', data: '2026-09-23', vendedor: 'Loja / Balcão Central', faturamento: 10400.00, numVendas: 118, ticketMedio: 88.14, createdAt: '2026-09-23T18:00:00Z', origem: 'demo' },

  // LANÇAMENTO DE TESTE OFICIAL DO PROMPT (Seção 45):
  // Data: 24/09/2026 | Vendedor: Arnaldo | Faturamento: R$ 12.568,30 | Nº de vendas: 100 -> Ticket médio: R$ 125,68
  {
    id: 'e-test-45',
    data: '2026-09-24',
    vendedor: 'Arnaldo',
    faturamento: 12568.30,
    numVendas: 100,
    ticketMedio: 125.68,
    observacao: 'Lançamento de validação oficial do sistema',
    createdAt: '2026-09-24T14:30:00Z',
    origem: 'manual'
  },
  { id: 'e-53', data: '2026-09-24', vendedor: 'Alessandra', faturamento: 4500.00, numVendas: 35, ticketMedio: 128.57, createdAt: '2026-09-24T15:00:00Z', origem: 'demo' },
  { id: 'e-54', data: '2026-09-24', vendedor: 'Felipe', faturamento: 3950.00, numVendas: 30, ticketMedio: 131.67, createdAt: '2026-09-24T15:00:00Z', origem: 'demo' },
  { id: 'e-55', data: '2026-09-24', vendedor: 'Loja / Balcão Central', faturamento: 11200.00, numVendas: 125, ticketMedio: 89.60, createdAt: '2026-09-24T15:00:00Z', origem: 'demo' },
];
